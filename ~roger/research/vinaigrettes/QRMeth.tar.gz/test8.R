# Some further tests to verify that things fit together properly
n = 5000
p = 5
x = matrix(rnorm(n*p),n,p)
y = rnorm(n)
f = rq(y ~ x, tau = 1:4/5, method = "pfnb")
g = rq(y ~ x, tau = 1:4/5, method = "conquer")
t1 <- system.time(fs1 <- summary(f, se = "boot", bsmethod = "xy")) 
t2 <- system.time(fs2 <- summary(f, se = "boot", bsmethod = "pwy")) 
t3 <- system.time(fs3 <- summary(f, se = "boot", bsmethod = "pwxy")) 
t4 <- system.time(fs4 <- summary(f, se = "boot", bsmethod = "wild")) 
t5 <- system.time(fs5 <- summary(g))
t6 <- system.time(fs6 <- summary(f, se = "boot", bsmethod = "pxy")) 
