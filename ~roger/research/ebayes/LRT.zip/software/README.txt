README file for software for Gu, Koenker, Volgushev (2017), Testing for Homogeneity in Mixture Models

1. 	Table 1: theoretical critical value for testing of homogeneity for mixture of normal. 
	R code: LR_CV.R
	Remark: Results may be different from each run unless set seed. 

2. 	Table 2: Simulation of null LRT behaviour , in comparison to theoretical asymptotic cv in Table 1. 
	R code: sim2.R for simulation and SizeTab.R generates the table 

3. 	Table 3: Bootstrap critical value for LRT for testing homogeneity of Gaussian location parameter. [this generates exact cv, which can be enjoyed by location shift model due to invariance. 
	R code: bcval_tabulate_norm.R for simulation and bcval_tabulate_norma.R for analysis

4. 	On the fly bootstrap cv: See demo_poisson.R for an example
