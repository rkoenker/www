load("bcval_tabulate_norm.Rda")
bcval <- matrix(0,3,3)
for (i in 1:3) A = A + AK[[i]]
for (i in 1:3){
bcval[i,] <- quantile(A[i,],c(0.9,0.95,0.99))
}