# Tabulate bootstrap critical value for normal mixture
# no restrcition on support
# Repeat 500 times 
# for different sample size n = 100,200,500


require(REBayes)


require(doMC) #loads multicore and foreach automatically.
registerDoMC(3) # intention to use 3 cores
require(REBayes)

system("hostname")
date()
sessionInfo()
set.seed(1200)
opt <- list(set.seed = FALSE)



logLik0 <- function(x) sum(dnorm(x - mean(x), log = TRUE)) 

ns <- c(100,200,500)
B <- 2000
A <- matrix(0,length(ns),B)
AK <- foreach(k = 1:3) %dopar% {
require(REBayes)
n = ns[k]
for (i in 1:B){
x = rnorm(n,0,1)
A[k,i] <- 2*(GLmix(x)$logLik - logLik0(x))
}
A
}