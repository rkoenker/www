#' @name citations
#' @title Binomial citation data
#' @description  Binomial citation data  from Clarivate Journal Citations for 2010-2019 for 86
#' selected journals in econometrics and statistics.  This form of the data can
#' be reproduced from the raw data downloaded from Clarivate and stored the package
#' directory inst/extdata.  See the function \code{Cites} and related code that produces
#' a matrix of citation counts, which can be converted to binomials with the aid of the
#' function \code{countsToBinomial} from the package \pkg{BradleyTerry2} by David Firth.
#' 
#' @usage citations
#' @format a data frame with 2014 rows and 4 variables
#' \describe{
#' 	\item{T1}{Player i}
#' 	\item{T2}{Player j}
#'	\item{W}{wins for player i}
#'	\item{L}{wins for player j}
#' }
#' @source \url{https://clarivate.com/webofsciencegroup/solutions/journal-citation-reports/}
NULL
