C Output from Public domain Ratfor, version 1.05
      double precision function dmvg2(x, mu, cov)
      double precision x(2), mu(2), cov(2,2)
      double precision s(2), rho, z(2), k
      double precision one, two, pi
      parameter(one = 1.0d0)
      parameter(two = 2.0d0)
      parameter(pi = 3.141592653589793d0)
      s(1) = dsqrt(cov(1,1))
      s(2) = dsqrt(cov(2,2))
      rho = cov(1,2)/(s(1)*s(2))
      k = 1/(two*pi*s(1)*s(2)*dsqrt(one - rho**2))
      z(1) = (x(1)-mu(1))/s(1)
      z(2) = (x(2)-mu(2))/s(2)
      dmvg2 = k * dexp(-(z(1)**2 - two*rho*z(1)*z(2) + z(2)**2)/(two*(on
     *e - rho**2)))
      return
      end
      subroutine fdpr(p, m, n, b, t, cov, gx, gy, r)
      integer p, m, n, t(2,n)
      double precision b(p), x(2), gx(2,m), gy(2,m), s(2,2), r(n)
      double precision den, an, ad, w, dmvg2, cov(p-1,p-1)
      double precision zero, one
      parameter(zero = 0.0d0)
      parameter(one = 1.0d0)
      do23000 i = 1,n
      an = zero
      ad = zero
      if(t(1,i) .gt. 1)then
      do23004 j = 1,m
      x(1) = b(t(1,i))
      x(2) = b(t(2,i))
      s(1,1) = cov(t(1,i)-1,t(1,i)-1)
      s(1,2) = cov(t(1,i)-1,t(2,i)-1)
      s(2,1) = cov(t(2,i)-1,t(1,i)-1)
      s(2,2) = cov(t(2,i)-1,t(2,i)-1)
      den = dmvg2(x, gx(1,j), s)
      if(gx(1,j) .le. gx(2,j))then
      w = one
      else
      w = zero
      endif
      an = an + den * w * gy(1,j) * gy(2,j)
      ad = ad + den * gy(1,j) * gy(2,j)
23004 continue
23005 continue
      r(i) = an/ad
      endif
23000 continue
23001 continue
      return
      end
