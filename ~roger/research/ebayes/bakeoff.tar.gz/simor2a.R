# Means over the replications of the simulations
require(Hmisc)
load("simor2.Rda")
B <- array(unlist(AK),c(1000,3,2,5))
MSE <- apply(B,2:4,mean)
MSE <- matrix(round(aperm(MSE,c(2,3,1)) * 200),2,15)
dimnames(MSE) <- list(c("Oracle","EBKM"),rep(1:5,3))
latex(MSE, file = "simor2a.tex", rowlabel = "", where = "!htbp", 
      caption = "MSE based on 1000 replications", caption.loc = "bottom", 
      cgroup = paste("s =",c(25,50,100)))



require(Hmisc)
B <- array(unlist(AK),c(1000,3,2,5))
MSE <- apply(B,2:4,mean)
MSE <- matrix(round(aperm(MSE,c(2,3,1)) * 500),2,15)
dimnames(MSE) <- list(c("EBMW","EBKM"),rep(1:5,3))
latex(MSE, file = "sim2a.tex", rowlabel = "", where = "!htbp", 
    caption = "MSE based on 1000 replications", caption.loc = "bottom", 
      cgroup = paste("s =",c(25,50,100)))



