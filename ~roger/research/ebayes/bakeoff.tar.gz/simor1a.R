# Means over the replications of the simulations
require(Hmisc)
load("simor1.Rda")
B <- array(unlist(AK),c(1000,4,2,4))
MSE <- apply(B,2:4,mean)
MSE <- matrix(round(aperm(MSE,c(2,3,1)) * 200),2,16)
dimnames(MSE) <- list(c("Oracle","EBKM"),rep(c(1,3,5,7),4))
latex(MSE, file = "simor1a.tex", rowlabel = "", where = "!htbp", 
      caption = "MSE based on 1000 replications", caption.loc = "bottom", 
      cgroup = paste("s =",c(10,20,40,80)))

