# Means over the replications of the simulations
load("sim2.Rda")


#Castillo and van der Vaart results
CS <- t(matrix(c(
111, 96, 94, 176, 165, 154, 267, 302, 307,
106, 92, 82, 169, 165, 152, 269, 280, 274,
103, 96, 93, 166, 177, 174, 271, 312, 319,
129, 83, 73, 205, 149, 130, 255, 279, 283,
125, 86, 68, 187, 148, 129, 273, 254, 245,
110, 81, 72, 162, 148, 142, 255, 294, 300,
175, 142, 70, 339, 284, 135, 676, 564, 252,
136, 92, 84, 206, 159, 139, 306, 261, 245,
142, 98, 53, 240, 160, 93, 399, 262, 151),9,9))
A <- matrix(NA,9,2)
CSA <- cbind(A, CS[,1:3], A, CS[,4:6], A, CS[,7:9])
CSlabs <- c("PM1", "PM2", "EBM", "PMed1", "PMed2", "EBMed", "HT", "HTO","EBMW")


require(Hmisc)
B <- array(unlist(AK),c(1000,3,2,5))
MSE <- apply(B,2:4,mean)
MSE <- matrix(round(aperm(MSE,c(2,3,1)) * 500),2,15)
MSE <- rbind(CSA,MSE)
dimnames(MSE) <- list(c(CSlabs, "EBMW","EBKM"),rep(1:5,3))
latex(MSE, file = "sim2a.tex", rowlabel = "", where = "!htbp", 
    caption = "MSE based on 1000 replications", caption.loc = "bottom", 
      cgroup = paste("s =",c(25,50,100)))



