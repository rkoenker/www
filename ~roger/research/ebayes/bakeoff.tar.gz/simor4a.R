# Means over the replications of the simulations
load("simor4.Rda")

require(Hmisc)
B <- array(unlist(AK),c(1000,2,6))
MSE <- apply(B,2:3,mean)
MSE <- matrix(round(MSE * 1000),2,6)
dimnames(MSE) <- list(c("Oracle","EBKM"),2:7)
latex(MSE, file = "simor4a.tex", rowlabel = "", caption = "MSE 1000 replications", 
  caption.loc = "bottom", where = "!htbp")
