# Means over the replications of the simulations
load("sim4.Rda")

# Results from BPPD
BPPD <- t(matrix(c(299.30,385.68,424.09,450.20,474.28,493.03,
306.94,353.79,270.90,205.43,182.99,168.83,
368.45,679.17,671.34,374.01,213.66,160.14,
267.83,315.70,266.80,213.23,192.98,177.20),6,4))


require(Hmisc)
B <- array(unlist(AK),c(1000,2,6))
MSE <- apply(B,2:3,mean)
MSE <- matrix(round(MSE * 1000),2,6)
MSE <- rbind(round(BPPD), MSE)
dimnames(MSE) <- list(c("BL", "DL(1/n)","DL(1/2)","HS","EBMW","EBKM"),2:7)
latex(MSE, file = "sim4a.tex", rowlabel = "", 
  caption = "MSE based on 100 replications for the first four rows and on 1000 replications
  for the last two rows", caption.loc = "bottom", where = "!htbp")
