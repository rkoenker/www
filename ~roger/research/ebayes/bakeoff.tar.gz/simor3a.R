# Means over the replications of the simulations
load("simor3.Rda")

require(Hmisc)
B <- array(unlist(AK),c(1000,3,2,5))
MSE <- apply(B,2:4,mean)
MSE <- matrix(round(aperm(MSE,c(2,3,1)) * 500),2,15)
dimnames(MSE) <- list(c("Oracle","EBKM"),rep(1:5,3))
latex(MSE, file = "simor3a.tex", rowlabel = "", 
       caption = "MSE based on 1000 replications", caption.loc = "bottom", 
      where = "!htbp", cgroup = paste("s =",c(25,50,100)))



