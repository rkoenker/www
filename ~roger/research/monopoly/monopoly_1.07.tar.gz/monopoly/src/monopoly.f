C Output from Public domain Ratfor, version 1.0
      subroutine demand(n,p,x)
      double precision p(n),x(n)
      double precision a0,a1,a2,s,normrnd
      integer n,i
      parameter(a0 = 5)
      parameter(a1 = -0.5)
      parameter(a2 = -0.35)
      parameter(s = 0.05)
      parameter(rho = 0.6)
      call rndstart()
      do23000 i = 1,n 
      x(i) = a0 + a1*log(p(i)) + .5 * a2 * (log(p(i)))**2
      x(i) = exp(x(i) + s * normrnd())
23000 continue
23001 continue
      call rndend()
      return
      end
