# This needs to be fixed in light of the phantom station!!!
L <- read.csv("lines.csv", header = TRUE)
a <- read.csv("arcs.csv", header = TRUE)
D <- read.csv("tube.csv", header = TRUE)
a <- a[!a[,2]==307,] # Drop phantom link to node 307
a <- as.matrix(a) # Annoying feature of rbind for dataframes!
a <- rbind(a,a[,c(2,1,3)])
plot(D[,3],D[,2],cex = .5, col = "grey", xlab = "longitude", ylab = "latitude")
ss <- a[,3] # All the Line 1 arcs
for(i in 1:length(ss)){
    segments(D[D[,1] == a[i,1],3], D[D[,1] == a[i,1],2], 
	 D[D[,1] == a[i,2],3], D[D[,1] == a[i,2],2], col = a[i,3])
}
