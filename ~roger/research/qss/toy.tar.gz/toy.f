C Output from Public domain Ratfor, version 1.0
      subroutine toy(n,a,s)
      integer n
      double precision a(n),s
      s = 0.0d0
      do23000 i = 1,n
      s = s + a(i)
23000 continue
23001 continue
      return
      end
