subroutine toy(n,a,s)
integer n
double precision a(n),s
s = 0.0d0
do i = 1,n
	s = s + a(i)
return
end
	
