
toy <- function(x){
	n <- length(x)
	z <- .Fortran("toy",
		as.integer(n),
		as.double(x),
		s = double(1))
	return(z$s)
	}
