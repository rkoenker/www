dyn.load("toy.so")
source("toy.q")
x <- rnorm(10)
z <- toy(x)

