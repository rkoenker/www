require(quantreg)
HK.test.results <- lapply(NP.data, HK.test)
