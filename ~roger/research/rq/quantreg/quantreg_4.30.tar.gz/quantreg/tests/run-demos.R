library(quantreg)

(dDIR <- system.file("demo", package = "quantreg"))
setwd(dDIR)
set.seed(1) # since some demos randomly generate

cat("Running demos from package 'quantreg' : \n\n")
for(f in list.files()) {
    cat("\n", f," :\n", paste(rep.int("-", nchar(f)), collapse=''),
        "\n", sep='')

    source(f, echo = TRUE)
}
