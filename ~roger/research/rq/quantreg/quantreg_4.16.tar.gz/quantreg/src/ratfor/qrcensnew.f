      SUBROUTINE qrcens(xx,y,yc,nx,nobs,beta,wa,nobs1,nx2,z,pr,prcens,
     &                  cens,varb,varn,toler,optimum,theta)
c
c     Version: 12 / March / 97      Copyright: Bernd Fitzenberger
c
c     Change: If current solution interpolates more than nx
c             data points then check all possible directional
c             derivatives given (nx-1) interpolated data points
c             Marked with: c       Change March 97
c             call setuptable 
c
c     Requires NAG-Subroutine Libary routines: f03aff,x02ajf,f04asf,f04aff
c              and matrix multiplication routine mab8
c     Required changes:
c     mnobs = Number of observations
c     mnx   = Maximum number of regressors
c
      IMPLICIT REAL*8 (a-h,o-z)
      INTEGER mnobs,mnx
c     Changes Required
c      PARAMETER (mnobs=59820,mnx=28)
      PARAMETER (mnobs=100,mnx=4)
c     End of Changes Required
      INTEGER nobs,nx,in,out,prcens(nobs),nx1,nx2,nobs1,setuptable,
     & idgt,ier,upfreq,pklim,outsave,outmcr,varin
      REAL*8 zero,one,two,big,theta,omtheta,r,minsum,minmcr,mcrin
      PARAMETER (zero=0.d0,one=1.d0,two=2.d0,
     & big=1.d75,mnxsq=mnx*mnx,idgt=8,upfreq=400,pklim=50)
      INTEGER i,j,varb(nobs),varn(nx),kr,crun,var,cens(nobs),di,k,kl,
     & s,kount,pkount,l,i1,j1,bvar
      REAL*8 xx(nobs,nx),y(nobs),yc(nobs),beta(nx),wa(nobs1,nx2),sum,
     & pr(nobs),z(nobs),toler,d,mini,maxi,pivot,b1(mnobs),b2(mnobs),
     & wk(mnxsq),wa1(mnxsq),wa2(mnxsq),savest(mnx),objective
c       Change March 97
      INTEGER ll,nllkm1,ill,varip(mnobs),bincoef,ifail,jindex(mnx),
     &        jhelp,taketup,dll,itabch
      REAL*8 resc(mnobs),dirderiv,x02ajf,id,workreal(mnobs),eps,
     & determ8,xttxk(mnx),pw(mnx),
     & weight(mnobs),worka(mnobs*mnx),lu(mnx*mnx),adet(mnx*mnx)
c       End Change March 97
      LOGICAL coef,varcens,optimum,sit1b,sit2bc,intbcens
      INTEGER numout,varout(mnobs),insave,numkount
      EXTERNAL tabprint,setuptabl,mab8,tabcheck,r,objective
      EXTERNAL bincoef,f03aff,x02ajf,dirderiv,f04asf
      DATA (weight(i),i=1,mnobs) / mnobs * 1.d0 /
      eps = X02AJF()
c     INITIALIZATION
      kr = 1
      itabch = 0
      setuptable = 0
      kount = 0
      numkount = 0
      pkount = 1
      nx1=nx+1
      minsum = big
c      write(6,'(a,i10)') 'kount = ',kount
c      write(6,'(a,i10)') 'nx2 = ',nx2
c      write(6,'(a,i10)') 'nobs1 = ',nobs1
c      theta = 0.5d0
      omtheta=one-theta
c      write(6,'(a,f5.2)') 'theta = ',theta
      optimum = .false.
c     Initialize z
      do 20 i = 1,nobs
      if (yc(i)-y(i).lt.toler) then
         z(i) = 0.d0
         if (cens(i).ne.1) then
            write(6,'(a)') 'cens(.) incorrect'
            goto 1000
            endif
         else
         z(i) = yc(i) - y(i)
         if (cens(i).ne.0) then
            write(6,'(a)') 'cens(.) incorrect'
            goto 1000
            endif
         endif
 20      continue
c     INITIALIZATION 
      kl = 1
      do 1040 i = 1,nobs
         wa(i,nx1) = y(i)
         varb(i) = i
 1040    continue
      do 1050 j = 1,nx
         do 1060 i = 1,nobs
            wa(i,j) = xx(i,j)
 1060       continue
         varn(j) = nobs+j
 1050    continue
c      write(6,'(/,a,/)') 'Start Stage 1 '
 10   continue
c     Adjust Basis for negative variables
      do 1070 i = 1,nobs
      if (wa(i,nx1).lt.zero) then
         varb(i) = -varb(i)
         do 1080 j = 1,nx1
            wa(i,j) = -wa(i,j)
 1080       continue
         endif
 1070    continue
c     Put current values of coef's from into beta and calculate fit pr
      do 1090 j = 1,nx
         beta(j) = 0.d0
 1090    continue
      do 1100 i = 1,kl-1
         beta(abs(varb(i))-nobs) = dble(isign(1,varb(i)))*wa(i,nx1)
 1100    continue
c     Determine PRedicted values: pr
      call mab8(xx,nobs,nx,beta,nx,1,pr)
c      call dgemul(xx,nobs,'N',beta,nx,'N',pr,
c     &            nobs,nobs,nx,1)
c
c       do 1110 j = 1,nx   
c 1110    write(6,'(a,i3,a,f15.8)') 'beta(',j,') = ',beta(j)
c
c     Use current fit to determine if pr is censored 
c     and calculate wa(i,nx2) = sgn(y(i)-x(i)'beta)*(yc(i)-x(i)'beta)
c     prcens(i) = 0  if  x'b < yc
c                 1          =
c                 2          >
      do 1150 i = 1,nobs
         d = yc(i)-pr(i)
         if (d.gt.toler) then
            prcens(i) = 0
            else if (abs(d).le.toler) then
            prcens(i) = 1
            else
            prcens(i) = 2
            endif
 1150    continue
      sum = zero   
      do 25 i = 1,nobs
         var = abs(varb(i))
         if (var.gt.nobs) goto 25
            d = yc(var)-pr(var)
            wa(i,nx2) = sign(1.d0,y(var)-pr(var))*d
            sum = sum + r(theta,y(var)-min(pr(var),yc(var)))
 25      continue
      wa(nobs1,nx1) = sum
c      write(6,'(a,f15.8,/)') 'Value of Objective (25): ',wa(nobs1,nx1)
c      write(6,'(a,f15.8,/)') 'Value of Objective (25): ',
c     & wa(nobs1,nx1)/theta
c     Control Print of Tableau
c      call tabprint(wa,varb,varn,pr,prcens,z,nobs1,nobs,nx,nx2,
c     &              pkount,kl,cens)
c      if (pkount.eq.pklim) goto 1000
c     Control Print of Tableau
c
c     Calculate Marginal Cost - Stage 1
c
 30   do 80 j = 1,nx
         var = abs(varn(j))
         if (var.le.nobs) goto 80
         crun = 0
 35      wa(nobs1,j) = zero
         do 40 i = kl,nobs
            if (prcens(abs(varb(i))).eq.2) goto 40
            bvar = varb(i)
            d = wa(i,j)
            if (prcens(abs(varb(i))).eq.0) goto 50
            if ((d.lt.-toler).and.(varb(i).gt.0)) then
               d = d*theta
               goto 60
               endif
            if ((d.gt.toler).and.(varb(i).lt.0)) goto 50
            goto 40
 50         if ((wa(i,nx1).lt.toler).and.(d.gt.zero)) then
               bvar = -bvar
               d = -d
               endif
            if (bvar.gt.0) then
               d = d*theta
               else
               d = d*omtheta
               endif
 60         wa(nobs1,j) = wa(nobs1,j) + d
c         write(6,'(a,i7,a,i7,a,e16.9)') 
c     &    'MCR ohne nb: wa(',nobs1,',',j,') = ',wa(nobs1,j)/theta
 40         continue
         if (crun.eq.1) goto 80
         crun = 1
         if (wa(nobs1,j).lt.toler) then
c        Change sign in column b/c MC < 0 and MC of 
c              -varn(j) could be positive
            varn(j) = -varn(j)
            do 1155 i = 1,nobs
 1155          wa(i,j) = -wa(i,j)
            goto 35
            endif
 80      continue
c     Determine the vector to enter the basis or if optimal 
c     solution found - Stage 1
 90   mcrin = -one
      do 100 j = 1,nx
c         write(6,'(a,i7,a,i7)') 
c     &        'varn(',j,') = ',varn(j)
c         write(6,'(a,i7,a,i7,a,e16.9)') 
c     &        'MCR: wa(',nobs1,',',j,') = ',wa(nobs1,j)
c         write(6,'(a,i7,a,i7,a,e16.9)') 
c     &        'MCR: wa(',nobs1,',',j,') = ',wa(nobs1,j)/theta
         var = abs(varn(j))
         if (var.le.nobs) goto 100
         if (wa(nobs1,j).le.mcrin) goto 100
         mcrin = wa(nobs1,j)
         in = j
 100     continue
c     Control Print of Tableau
c      call tabprint(wa,varb,varn,pr,prcens,z,nobs1,nobs,nx,nx2,
c     &              pkount,kl,cens)
c      if (pkount.eq.pklim) goto 1000
c     Control Print of Tableau
      if (mcrin.le.toler) then
c       write(6,'(/,a,f15.8)') 'Value of Objective : ',wa(nobs1,nx1)
c       write(6,'(/,a,f15.8)') 'Value of Objective : ',
c     &                wa(nobs1,nx1)/theta
c      do 1160 j = 1,nx
c         write(6,'(a,i3,a,f15.8)') 'beta(',j,') = ',beta(j)
c 1160    continue
c        Go To State 2 and recalculate the Marginal Costs
c         write(6,'(/,a,/)') 'Start Stage 2 (goto 230)'
         goto 230   
         endif
c *********
c      write(6,'(2(a,i8,2x))') 'Iter:',kount,'Into Basis Var:',varn(in)
c *********
c     DETERMINE the vector to leave the basis
 110  k = 0
      do 115 i = kl,nobs
         d = wa(i,in)
         b1(i) = big
         b2(i) = big
         if (abs(d).le.toler) go to 115
         b1(i) = wa(i,nx1)/d
         b2(i) = wa(i,nx2)/d
 115     continue
      varin = abs(varn(in))
 120  mini = big   
      numout = 0
      do 130 i = kl,nobs
         if ((b1(i).ge.mini).or.(b1(i).lt.toler)) goto 130
         mini = b1(i)
c         out = i
 130     continue
      do 150 i = kl,nobs
         sit1b = abs(b1(i)-mini).le.toler
         sit2bc = (b2(i).le.mini+toler).and.(b2(i).gt.toler)
         if (.not.(sit1b.or.sit2bc)) go to 150
c        s = 0
         pivot = wa(i,in)
         if (sit1b) then
            numout = numout + 1
            varout(numout) = i
            b1(i) = big
            if (.not.(sit2bc)) then
c               mcrin = mcrin - two*pivot
               mcrin = mcrin - pivot
c              s = 1            
               else 
               b2(i) = big
c               mcrin = mcrin - pivot
               mcrin = mcrin - theta*pivot
c              s = 3 and s = 5
               endif
            else
            b2(i) = big
c            mcrin = mcrin + abs(pivot)
            mcrin = mcrin + omtheta*abs(pivot)
c           s = 2 and s = 4
            endif
 150     continue
c      pivot = wa(out,in)
c      write(6,'(a,i7,3(/a,f8.3))')
c     & 'Check to leave Basis Var # : ',varb(out),' Pivot = ',pivot,
c     & ' b1(out) = ',wa(out,nx1)/pivot,
c     & ' b2(out) = ',wa(out,nx2)/pivot
      if (mcrin.gt.toler) then
c         write(6,'(a,i7,a,i7,a,e16.9)') 
c     &        'MCR: wa(',nobs1,',',in,') = ',mcrin
         outsave = out
         goto 120
         endif
      if (numout.ge.1) out = varout(1)
c      write(6,'(/,a,i7,a,i7,a,e16.9,/)') 
c     &        'MCR: wa(',nobs1,',',in,') = ',mcrin
      pivot = wa(out,in)
      insave = in
c Pivot on WA(out,in)         
c      write(6,'(a,i6,a,i6,a,f8.3,2(/a,i7))') 'Pivot on WA(',
c     &          out,',',in,') = ',pivot,
c     &         'Out Var # ',varb(out),'In  Var # ',varn(in)
      do 170 j = kr,nx1
         if (j.eq.in) goto 170
         wa(out,j) = wa(out,j)/pivot
 170     continue
      do 190 i = 1,nobs
      if (i.eq.out) goto 190
      d = wa(i,in)
      do 180 j = kr,nx1
         if (j.eq.in) goto 180
         wa(i,j) = wa(i,j) - d*wa(out,j)
 180        continue
 190     continue   
      do 200 i = 1,nobs   
      if (i.eq.out) goto 200
      wa(i,in) = -wa(i,in)/pivot
 200     continue
      wa(out,in) = one/pivot
      di = varb(out)
      varb(out) = varn(in)
      varn(in) = di
      kount = kount + 1
c   end after pklim iter
      if ((kount-1).eq.pklim) then
         write(6,'(a)') 'MAXITER reached !!!!!!!!'
c      write(6,'(a)') 'Current NonBasis-Variables'
c         do 201 j1 = 1,nx 
c            write(6,'(i3,a,i10)') j1,
c     &            'th-Interpolated Observation = ',varn(j1)
c 201        continue
         goto 1000
         endif
c   end after pklim iter
c     Interchange Rows in Stage 1
      do 1180 j = kr,nx2
      d = wa(out,j)
      wa(out,j) = wa(kl,j)
      wa(kl,j) = d
 1180    continue
      di = varb(out)
      varb(out) = varb(kl)
      varb(kl) = di
      kl = kl + 1
c      write(6,'(2(a10,i6))') 'Kount = ',kount,' kl = ',kl
c     update if mod(kount,upfreq) = 0
      if (mod(kount,upfreq).eq.0) then
c      write(6,'(/,a,/,a,i6,a)') 
c     &   '***************************************',
c     &   'Tableau Update after ',kount,' iterations '
      call setuptabl(wa,varn,varb,xx,y,yc,beta,pr,prcens,cens,
     &                     nobs,nx,nobs1,nx2,kl,toler,theta)
c      write(6,*) 'Setuptable '
      call tabcheck(xx,wa,varb,varn,nobs1,nobs,nx,nx2,toler)
      itabch = itabch + 1
      if (itabch.eq.pklim) goto 1000
c      do 1190 j1 = 1,nx   
c         write(6,'(a,i3,a,f15.8)') 'beta(',j1,') = ',beta(j1)
c 1190       continue
c      write(6,'(/,a,f15.8,/)') 'Value of Objective : ',wa(nobs1,nx1)
c      write(6,'(/,a,f15.8,/)') 'Value of Objective : ',
c     &     wa(nobs1,nx1)/theta
      wa(nobs1,nx1) = big
      do 1200 j1 = 1,nx   
         write(6,'(i3,a,i10)') j1,
     &            'th-Interpolated Observation = ',varn(j1)
 1200       continue
c      write(6,*) ' '
      endif
c     end of update if mod(kount,upfreq) = 0      
c     Control Print of Tableau
c      call tabprint(wa,varb,varn,pr,prcens,z,nobs1,nobs,nx,nx2,
c     &              pkount,kl,cens)
c      if (pkount.eq.pklim) goto 1000
c     Control Print of Tableau
      if (kl.le.nx) go to 10
c      
c     Start Stage 2
c
c      write(6,'(/,a,/)') 'Start Stage 2 (205)'
 205  continue
c     Adjust Basis for negative variables
      do 1210 i = 1,nobs
      if (wa(i,nx1).lt.zero) then
         varb(i) = -varb(i)
         do 1220 j = 1,nx1
            wa(i,j) = -wa(i,j)
 1220       continue
         endif
 1210    continue
c     Put current values of coef's from into beta and calculate fit pr
      do 1230 j = 1,nx
      beta(j) = zero
 1230 continue
      do 1240 i = 1,kl-1
         beta(abs(varb(i))-nobs) = dble(isign(1,varb(i)))*wa(i,nx1)
 1240    continue
c    Determine PRedicted values : pr
      call mab8(xx,nobs,nx,beta,nx,1,pr)
c      call dgemul(xx,nobs,'N',beta,nx,'N',pr,
c     &            nobs,nobs,nx,1)
c
c      do 1250 j = 1,nx   
c         write(6,'(a,i3,a,f15.8)') 'beta(',j,') = ',beta(j)
c 1250    continue
c     Check for Update : if residual > toler
c      do 1260 j = 1,nx
c      var = abs(varn(j))
c      if (var.le.nobs) then
c         d = abs(y(var)-min(pr(var),yc(var)))
c         if (d.gt.10.d0*toler) then  
c            write(6,'(/,a,/,a,i6,a)') 
c     &         '***************************************',
c     &         'Tableau Update after ',kount,' iterations - Res'
c            call setuptabl(wa,varn,varb,xx,y,yc,beta,pr,prcens,cens,
c     &                     nobs,nx,nobs1,nx2,kl,toler,theta)
c      write(6,*) 'Setuptable '
c      call tabcheck(xx,wa,varb,varn,nobs1,nobs,nx,nx2,toler)
c      do 1270 j1 = 1,nx   
c         write(6,'(a,i3,a,f15.8)') 'beta(',j1,') = ',beta(j1)
c 1270       continue
c      write(6,'(/,a,f15.8,/)') 'Value of Objective : ',wa(nobs1,nx1)
c      wa(nobs1,nx1) = big
c      do 1280 j1 = 1,nx   
c         write(6,'(i3,a,i10)') j1,
c     &            'th-Interpolated Observation = ',varn(j1)
c 1280       continue
c      write(6,*) ' '
c            goto 205
c            endif
c         endif
c 1260 continue   
c     end of Check for Update : if residual > toler
c
c     Use current fit to determine if pr is censored 
c     and calculate wa(i,nx2) = sgn(y(i)-x(i)'beta)*(yc(i)-x(i)'beta)
c     prcens(i) = 0  if  x'b < yc
c                 1          =
c                 2          >
      do 1290 i = 1,nobs
         d = yc(i)-pr(i)
         if (d.gt.toler) then
            prcens(i) = 0
            else if (abs(d).le.toler) then
            prcens(i) = 1
            else
            prcens(i) = 2
            endif
 1290    continue
      sum = zero   
c      do 215 i = kl,nobs
      do 215 i = 1,nobs
         var = abs(varb(i))
         if (var.gt.nobs) goto 215
            d = yc(var)-pr(var)
            wa(i,nx2) = sign(1.d0,y(var)-pr(var))*d
            sum = sum + r(theta,y(var)-min(pr(var),yc(var)))
 215     continue
c      write(6,'(a,f15.8,/)') 'Value of Objective (215) : ',sum
c      write(6,'(a,f15.8,/)') 'Value of Objective (215): ',sum/theta
c
c     Keep lowest value of objective reached
c
c      do 1110 j = 1,nx   
c 1110    write(6,'(a,i3,a,f15.8)') 'beta(',j,') = ',beta(j)
      if (sum.lt.(minsum-(toler/1.d1))) then
         do j1 = 1,nx
            savest(j1) = beta(j1)
            enddo
         minsum = sum
         optimum = .false.
c
c     Stop if iteration on same value of objective
c
      else if ( (setuptable.eq.1) .and.
     &   (abs(sum-minsum).lt.(toler/1.d1) ) ) then
         optimum = .true.
         goto 1000
         endif
c
c     Increase or No Change in Objective
c
      if (wa(nobs1,nx1)-sum.le.-toler) then
         write(6,'(3(/a40)/)')
     &    '*************************************',
     &    '******Increase in Objective**********',
     &    '*************************************'
c         write(6,'(/,a,f15.8,/)') 'Old Value of Objective : ',
c     &                             wa(nobs1,nx1)
c         write(6,'(/,a,f15.8,/)') 'New Value of Objective : ',
c     &                             sum
c         do 1307 j1 = 1,nx   
c 1307       write(6,'(a,i3,a,f15.8)') 'beta(',j1,') = ',beta(j1)
         if (setuptable.eq.0) then
c           write(6,'(/,a,/,a,i6,a)') 
c     &      '***************************************',
c     &      'Tableau Update after ',kount,' iterations '
c            write(6,'(/,a,/)') 'Before SETUPTABLE :'
c            do j = 1,nx
c               write(6,'(a,i7,a,i7,a,e16.9)') 
c     &           'MCR: wa(',nobs1,',',j,') = ',wa(nobs1,j)
c               enddo
            call setuptabl(wa,varn,varb,xx,y,yc,beta,pr,prcens,cens,
     &                  nobs,nx,nobs1,nx2,kl,toler,theta)
            call tabcheck(xx,wa,varb,varn,nobs1,nobs,nx,nx2,toler)
            itabch = itabch + 1
            if (itabch.eq.pklim) goto 1000
c            write(6,'(/,a,/)') 'After SETUPTABLE :'
c            do 1360 j1 = 1,nx   
c 1360          write(6,'(a,i3,a,f15.8)') 'beta(',j1,') = ',beta(j1)
            setuptable = 1
            endif
      else if (wa(nobs1,nx1)-sum.le.toler) then
c         write(6,'(3(/a40)/)')
c     &    '*************************************',
c     &    '******No Change in Objective*********',
c     &    '*************************************'
c         write(6,'(/,a,f15.8,/)') 'Old Value of Objective : ',
c     &                             wa(nobs1,nx1)
c         write(6,'(/,a,f15.8,/)') 'New Value of Objective : ',
c     &                             sum
         if (setuptable.eq.0) then
c            write(6,'(/,a,/)') 'Before SETUPTABLE :'
c            do j = 1,nx
c               write(6,'(a,i7,a,i7,a,e16.9)') 
c     &           'MCR: wa(',nobs1,',',j,') = ',wa(nobs1,j)
c               enddo
            call setuptabl(wa,varn,varb,xx,y,yc,beta,pr,prcens,cens,
     &                  nobs,nx,nobs1,nx2,kl,toler,theta)
            call tabcheck(xx,wa,varb,varn,nobs1,nobs,nx,nx2,toler)
            itabch = itabch + 1
            if (itabch.eq.pklim) goto 1000
c            write(6,'(/,a,/)') 'After SETUPTABLE :'
c            do 1361 j1 = 1,nx   
c 1361          write(6,'(a,i3,a,f15.8)') 'beta(',j1,') = ',beta(j1)
            setuptable = 1
            else if (optimum) then
            do 1300 j1 = 1,nx   
               beta(j1) = savest(j1)
 1300          continue
            goto 1000
            else
            write(6,'(a)') 'No SETUPTABLE - No OPTIMUM'
            endif
         endif
      wa(nobs1,nx1) = sum
c     Control Print of Tableau
c      call tabprint(wa,varb,varn,pr,prcens,z,nobs1,nobs,nx,nx2,
c     &              pkount,kl,cens)
c      if (pkount.eq.pklim) goto 1000
c     Control Print of Tableau
c
c     Calculate Marginal Cost - Stage 2
c
 230  continue
c     Reorder rows
      kl = 1
      do i = 1,nobs
         if (abs(varb(i)).gt.nobs) then
            di = varb(i)
            varb(i) = varb(kl)
            varb(kl) = di
            do jhelp = 1,nx2
               d = wa(i,jhelp)
               wa(i,jhelp) = wa(kl,jhelp)
               wa(kl,jhelp) = d
               enddo
            kl = kl + 1
            endif
         enddo         
c      write(6,'(a)') 'Start calculating MCR - Stage 2'
      do 280 j = 1,nx
         var = abs(varn(j))
c         write(6,'(a15,i5)') ' var = ',var
         if (var.gt.nobs) then
            coef = .true.
            else 
            coef = .false.
            endif
         crun = 0
 235     wa(nobs1,j) = zero
         do 240 i = kl,nobs
            if (prcens(abs(varb(i))).eq.2) goto 240
            bvar = varb(i)
            d = wa(i,j)
            if (prcens(abs(varb(i))).eq.0) goto 250
            if ((d.lt.-toler).and.(varb(i).gt.0)) then
               d = d*theta
               goto 260
               endif
            if ((d.gt.toler).and.(varb(i).lt.0)) goto 250
            goto 240
 250        if ((wa(i,nx1).lt.toler).and.(d.gt.zero)) then
               bvar = -bvar
               d = -d
               endif
            if (bvar.gt.0) then
               d = d*theta
               else
               d = d*omtheta
               endif
 260        wa(nobs1,j) = wa(nobs1,j) + d
c         write(6,'(a,i4,a,i2,a,f15.9)') 
c     &        'MCR ohne nb: wa(',nobs1,',',j,') = ',wa(nobs1,j)/theta
 240        continue
c      write(6,'(5(a15,i5,/),2(a15,f15.9,/))')
c     & 'var = ',var,' cens(var) = ',cens(var),
c     & ' prcens(var) = ',prcens(var),
c     & ' j = ',j,' varn(j) = ',varn(j),' omtheta = ',omtheta,
c     & ' wa(nobs1,j) = ',wa(nobs1,j)/theta
      if (coef) goto 270
c     Next line for case when censored obs in nonbasis
      if ((cens(var).eq.1).and.(varn(j).lt.0)) goto 270
      if (varn(j).gt.0) then 
         wa(nobs1,j) = wa(nobs1,j) - theta
         else 
         wa(nobs1,j) = wa(nobs1,j) - omtheta
         endif
c         write(6,'(a,i4,a,i2,a,f15.9)') 
c     &        'MCR: wa(',nobs1,',',j,') = ',wa(nobs1,j)/theta
 270     if (crun.eq.1) goto 280
      crun = 1
c      if ( ((.not.coef).and.(wa(nobs1,j)+one.lt.toler)) .or.
c     &        ((     coef).and.(wa(nobs1,j)    .lt.toler)) ) then
       if (wa(nobs1,j).lt.toler) then
c        Change sign in column b/c MC < 0 and MC of 
c              -varn(j) could be positive
         varn(j) = -varn(j)
         do 1310 i = 1,nobs
            wa(i,j) = -wa(i,j)
 1310       continue
c         write(6,'(a)') 'Calculate MCR again'
         goto 235
         endif
 280     continue
c     Control Print of Tableau
c      call tabprint(wa,varb,varn,pr,prcens,z,nobs1,nobs,nx,nx2,
c     &              pkount,kl,cens)
c      if (pkount.eq.pklim) goto 1000
c     Control Print of Tableau
c     Determine the vector to enter the basis or if optimal 
c               solution found - Stage 2
 290  mcrin = -one
      do 1320 j = 1,nx
c         write(6,'(a,i7,a,i7)') 
c     &        'varn(',j,') = ',varn(j)
c         write(6,'(a,i7,a,i7,a,e16.9)') 
c     &        'MCR: wa(',nobs1,',',j,') = ',wa(nobs1,j)
      if (wa(nobs1,j).gt.mcrin) then
         mcrin = wa(nobs1,j)
         in = j
         endif
 1320    continue
c      write(6,'(a12,e12.3)') 'mcrin = ',mcrin
c      write(6,'(a12,i5)') 'kl = ',kl
c     Control Print of Tableau
c      call tabprint(wa,varb,varn,pr,prcens,z,nobs1,nobs,nx,nx2,
c     &              pkount,kl,cens)
c      if (pkount.eq.pklim) goto 1000
c     Control Print of Tableau
c
c     Main Check for Optimum
c
      if (mcrin.le.toler) then
c        Change March 97
         ll = 0
c         do i = 1,nx
c            if (abs(varn(i)).le.nobs) then
c               ll = ll + 1
c               varip(ll) = abs(varn(i))
c               endif
c            enddo
         do i = 1,nobs
            if ( (abs(wa(i,nx1)).lt.toler) .and. 
     &           (abs(varb(i)).le.nobs) ) then
               ll = ll + 1
c               varip(ll) = varb(i)
               varip(ll) = abs(varb(i))
               endif
            enddo
c       help
c         write(6,'(a)') 'Current Coefficients'
c         do j = 1,nx   
c            write(6,'(a,i3,a,f15.8)') 'beta(',j,') = ',beta(j)
c            enddo    
c         write(6,'(a)') 'Data Points in basis interpolated'
c         do jhelp = 1,ll
c            write(6,'(2(a,i5))') 
c     &         'Data point (',jhelp,') = ',varip(jhelp)
c            enddo
c       end help 
c
c   If number of interpolated points coincides with 'nx' then goto 1326
c
c         write(6,'(2a,i6)') 'Number of interpolated points in basis ',
c     &       'at current solution : ',ll
c         write(6,'(a,i6)') 'kl =',kl
c         write(6,'(a)') 'Current NonBasis:'
c         do jhelp = 1,nx
c            write(6,'(2(a,i6))') ' varn(',jhelp,') = ',varn(jhelp)
c            enddo
         if (ll.eq.nx) goto 1326
c
c     Number of (nx-1)-tupels : ( ll 'over' nx-1 ) == nllkm1
c     sact     
      nllkm1 = bincoef(ll,nx-1)
      cfehler = 0
      do 1327 j = 0,ll**(nx-1)-1
         jhelp = j
         do 1328 j1 = 1,nx-1
            jindex(j1) = (jhelp/(ll**(nx-1-j1))) + 1
            jhelp = mod(jhelp,(ll**(nx-1-j1)))
c            write(6,'(a,i6,a,i12)') 'jindex(',j1,') = ',jindex(j1)
c            write(6,'(a,i6,a,i12)') 'varip(jindex(',j1,')) = ',
c     &                             varip(jindex(j1))
 1328       continue
         taketup = 1
         do 1329 j1 = 1,nx-2
            if (jindex(j1+1).le.jindex(j1)) taketup = 0
 1329       continue
         if (taketup.eq.1) then
c        get the nx-th data point
         do 1332 jj = 1,ll
            do jhelp = 1,nx-1
               if (jindex(jhelp).eq.jj) goto 1332
c           data point already among (nx-1)
               enddo            
            do 1331 j1 = 1,nx-1
               do 1331 j2 = 1,nx
                  adet((j2-1)*nx+j1) = xx(varip(jindex(j1)),j2)
                  lu((j2-1)*nx+j1) = xx(varip(jindex(j1)),j2)
 1331          continue
            do j2 = 1,nx
               adet((j2-1)*nx+nx) = xx(varip(jj),j2)
               lu((j2-1)*nx+nx) = xx(varip(jj),j2)
               enddo
cc         help
c            write(6,'(a)') 'Data Points considered'
c            do jhelp = 1,nx-1
c               write(6,'(a,i5)') 
c     &         'Data point (ip-kept) ',varip(jindex(jhelp))
c               enddo
c            write(6,'(a,i5)') 'jj = ',jj
c            write(6,'(a,i5)') 
c     &         'Data point (direct) ',varip(jj)
c            write(6,'(a)') 'lu'
c            write(6,'((2(a,f15.7,3x)))') 'lu(1,1) = ',lu(1),
c     &           'lu(1,2) = ',lu(1*2+1),'lu(2,1) = ',lu(2),
c     &           'lu(2,2) = ',lu(4)
cc         end help
            ifail = 1
            call f03aff(nx,eps,lu,nx,determ8,id,workreal,ifail)
            if (ifail.ne.0) then
c               write(6,'(a,i5)') 
c     &         'Fehler in f03aff (nx-1) 1332 - ifail = ',ifail
c            write(6,'((2(a,f15.7,3x)))') 'lu(1,1) = ',lu(1),
c     &           'lu(1,2) = ',lu(1*2+1),'lu(2,1) = ',lu(2),
c     &           'lu(2,2) = ',lu(4)
c               write(6,'(a)') 'Write lu '
c               do j1 = 1,nx
c                  write(6,'(10(f9.3,1x))') (lu((j2-1)*nx+j1),j2=1,nx)
c                  enddo
               endif
            determ8 = determ8*(2.d0**dble(id))
            if (abs(determ8).lt.toler) goto 1332
c       nx data points are not linearly independent: goto 1332
c
c       now determine orthogonal direction to (nx-1)-tuple
c
c            write(6,'(a,i5)') 
c     &         'Kein Fehler in f03aff - ifail = ',ifail
c            write(6,'(a)') 'data points linearly independent'
            do j2 = 1,nx-1
               xttxk(j2) = 0.d0
               do j1 = 1,nx-1
                  lu((j2-1)*(nx-1)+j1) = 0.d0
                  enddo
               enddo
            do j2 = 1,nx-1
               do jhelp = 1,nx
                  xttxk(j2) = xttxk(j2) + xx(varip(jindex(j2)),jhelp)*
     &                        xx(varip(jj),jhelp)
                  enddo
               do j1 = 1,nx-1
                  do jhelp = 1,nx
                  lu((j2-1)*(nx-1)+j1) = lu((j2-1)*(nx-1)+j1) 
     &        + xx(varip(jindex(j1)),jhelp)*xx(varip(jindex(j2)),jhelp)
                  enddo
                  adet((j2-1)*(nx-1)+j1) = lu((j2-1)*(nx-1)+j1) 
                  enddo
               enddo
c    help
c      write(6,'(a)') 'xtilde tr xk'
c      write(6,'((f12.4))') (xttxk(jhelp),jhelp=1,nx-1)
c      write(6,'(a)') 'xtilde tr xtilde'
c      do j1 = 1,nx-1
c         write(6,'(10(f12.4,1x))') (lu((j2-1)*(nx-1)+j1),j2=1,nx-1)
c         enddo
c    end help
c
c      Solve xtilde'xtilde*PW = lu*P = xttxk = xtilde'x(nx) wrt PW
c      lu is symmetric, positive definite 
c
               ifail = 1
c               call f03aff(nx-1,eps,lu,nx-1,determ8,id,workreal,ifail)
c               call f04ahf(nx-1,1,adet,nx-1,lu,nx-1,workreal,xttxk,
c     &                     nx-1,eps,pw,nx-1,worka,nx-1,jhelp,IFAIL)
               call f04asf(lu,nx-1,xttxk,nx-1,pw,workreal,worka,ifail)
               if (ifail.ne.0) write(6,'(a,i5)') 
     &            'Fehler in f04asf - ifail = ',ifail
               do j2 = 1,nx
                  workreal(j2) = 0.d0
                  do jhelp = 1,nx-1
                     workreal(j2) = workreal(j2) + 
     &                xx(varip(jindex(jhelp)),j2)*pw(jhelp)
                     enddo 
                  enddo
c     help
c            write(6,'(a)') 'xtilde * P'
c            do j1 = 1,nx
c               write(6,'(f12.4)') workreal(j1)
c               enddo
c     end help
               do j2 = 1,nx
                  pw(j2) = xx(varip(jj),j2)-workreal(j2)
                  enddo
c        pw is the possible search direction
c       help
c        write(6,'(a)') 'Search Direction'
c        write(6,'(/,4(a30,f12.4,/))') 'w(1) = ',pw(1),'w(2) = ',pw(2)
c        write(6,'(a)') 
c        write(6,'(a,f18.6)') 'Directional Derivative = ',
c     &     dirderiv(y,yc,xx,beta,pw,nobs,nx,theta,weight,toler)
c       end help
            if (dirderiv(y,yc,xx,beta,pw,nobs,nx,theta,weight,toler)
     &         .lt.-toler) goto 1333
            do j2 = 1,nx
               pw(j2) = -pw(j2)
               enddo
            if (dirderiv(y,yc,xx,beta,pw,nobs,nx,theta,weight,toler)
     &         .lt.-toler) goto 1333
            goto 1332
 1333       continue
c       help
c        write(6,'(a)') 'Search Direction'
c        write(6,'(/,2(a30,f12.4,/))') 'w(1) = ',pw(1),'w(2) = ',pw(2)
c        write(6,'(a)') 
c        write(6,'(a,f18.6)') 'Directional Derivative = ',
c     &     dirderiv(y,yc,xx,beta,pw,nobs,nx,theta,weight,toler)
c        create new simplex tableau
c            write(6,'(a)') 'Create new tableau'
            do i = 1,nobs
               varb(i) = i
               enddo
            do jhelp = 1,nx-1
               varn(jhelp) = varip(jindex(jhelp))
               varb(varip(jindex(jhelp))) = nobs + jhelp
               enddo
            varn(nx) = varip(jj)
            varb(varip(jj)) = nobs + nx
c         help
c            write(6,'(a)') 'call setuptabl'
c            do jhelp = 1,nx
c               write(6,'(2(a,i6))') ' varn(',jhelp,') = ',varn(jhelp)
c               enddo
c            do i = 1,nobs
c               write(6,'(2(a,i5))') 'varb(',i,') = ',varb(i)
c               enddo
cc        end help
            call setuptabl(wa,varn,varb,xx,y,yc,beta,pr,prcens,cens,
     &                     nobs,nx,nobs1,nx2,kl,toler,theta)
c         write(6,'(a,f15.8,/)') 'Value of Objective : ',wa(nobs1,nx1)
            call tabcheck(xx,wa,varb,varn,nobs1,nobs,nx,nx2,toler)
            itabch = itabch + 1
            if (itabch.eq.pklim) goto 1000
            goto 230
 1332       continue
c
c         endif if (taketup.eq.1) then
          endif
c
 1327     continue
 1326    continue
c        End Change March 97
c
c
c         write(6,'(3(/a40)/)')
c     &     '*************************************',
c     &     '******Optimal Solution found*********',
c     &     '*************************************'
c         write(6,'(a)') 'Current NonBasis-Variables'
c         do 1321 j1 = 1,nx 
c            write(6,'(i3,a,i10,a,e12.3)') j1,
c     &          'th-Interpolated Observation = ',varn(j1),
c     &          ' MCosts: ',wa(nobs1,j1)
c 1321       continue
         if ((numout.gt.1).and.(numkount.lt.5)) then
c            write(6,'(a12,i6)') 'numout = ',numout
c            write(6,'(a12,i6)') 'varout(1) = ',varout(1)
            numout = numout - 1
            do 1322 i = 1,numout
 1322          varout(i) = varout(i+1)
            out = varout(1)
            in = insave
            if (numout.eq.1) numkount = numkount + 1
            goto 365
            endif
c         write(6,'(a12,e12.3)') 'mcrin = ',mcrin
         if (mcrin.ge.-toler) then
            write(6,'(/,a,/)') 
     &      'Optimal Solution which is probably NON-UNIQUE'
            do 1325 j1 = 1,nx   
               savest(j1) = beta(j1) 
 1325          continue
            endif
c         do 1330 j = 1,nx
c 1330       write(6,'(a,i3,a,f15.8)') 'beta(',j,') = ',beta(j)
c         write(6,'(/,a,f15.8)') 'Value of Objective (minsum): ',minsum
         optimum = .true. 
         if (mcrin.lt.-toler) goto 1000
         endif
c *********
c      write(6,'(2(a,i8,2x))') 'Iter:',kount,'Into Basis Var:',varn(in)
c *********
c     DETERMINE the vector to leave the basis
 310  k = 0
      do 315 i = kl,nobs
         d = wa(i,in)
         b1(i) = big
         b2(i) = big
         if (abs(d).le.toler) go to 315
         b1(i) = wa(i,nx1)/d
         b2(i) = wa(i,nx2)/d
 315     continue
      varin = abs(varn(in))
      if ((varn(in).lt.0).and.(cens(varin).eq.0)) then
c        Case uncensored obs in nonbasis
         intbcens = .true.
         else
         intbcens = .false.
         endif
 320  mini = big   
      minmcr = big
      numout = 0
      out = 0
      do 330 i = kl,nobs
 330     if ((b1(i).lt.mini).and.(b1(i).ge.toler)) mini = b1(i)
      if (mini.gt.(big*toler)) then
         out = outmcr
         goto 365
         endif
c     Check if step such that censoring value reached for nonbasic var
c     to come into basis : IN
      if (intbcens) then
         if (mini.ge.z(varin)) then
            intbcens = .false.
            mcrin = mcrin + omtheta
            endif
         endif
c     Check, if there are more at mini
      do 350 i = kl,nobs
         sit1b = abs(b1(i)-mini).le.toler
         sit2bc = (b2(i).le.mini+toler).and.(b2(i).gt.toler)
         if (.not.(sit1b.or.sit2bc)) go to 350
c        s = 0
         pivot = wa(i,in)
         if (sit1b) then
            numout = numout + 1
            varout(numout) = i
            b1(i) = big
            if (.not.(sit2bc)) then
c               mcrin = mcrin - two*pivot
               mcrin = mcrin - pivot
c              s = 1            
               else 
               b2(i) = big
c               mcrin = mcrin - pivot
               mcrin = mcrin - theta*pivot
c              s = 3 and s = 5
               endif
            else
            b2(i) = big
c            mcrin = mcrin + abs(pivot)
            mcrin = mcrin + omtheta*abs(pivot)
c           s = 2 and s = 4
            endif
 350     continue
c      pivot = wa(out,in)
      if (numout.ge.1) out = varout(1)
      if (mcrin.lt.minmcr) then
         minmcr = mcrin
         outmcr = outsave
         endif
      if ((mcrin.gt.toler).and.(out.ne.0)) then
         outsave = out
         goto 320
         endif
      if (out.eq.0) then
         out = outsave
         endif
c      write(6,'(a,i7,3(/a,f8.3))')
c     & 'Check to leave Basis Var # : ',varb(out),' Pivot = ',pivot,
c     & ' b1(out) = ',wa(out,nx1)/pivot,
c     & ' b2(out) = ',wa(out,nx2)/pivot
c
 365  insave = in
      pivot = wa(out,in)
c
c Pivot on WA(out,in)         
c      write(6,'(a,i6,a,i6,a,f10.5,2(/a,i7))') 'Pivot on WA(',
c     &          out,',',in,') = ',pivot,
c     &         'Out Var # ',varb(out),'In  Var # ',varn(in)
      do 370 j = kr,nx1
         if (j.eq.in) goto 370
         wa(out,j) = wa(out,j)/pivot
 370     continue
      do 390 i = 1,nobs
         if (i.eq.out) goto 390
         d = wa(i,in)
         do 380 j = kr,nx1
            if (j.eq.in) goto 380
            wa(i,j) = wa(i,j) - d*wa(out,j)
 380        continue
 390     continue   
      do 400 i = 1,nobs   
         if (i.eq.out) goto 400
         wa(i,in) = -wa(i,in)/pivot
 400     continue
      wa(out,in) = one/pivot
      di = varb(out)
      varb(out) = varn(in)
      varn(in) = di
      kount = kount + 1
c   end after pklim iter
      if ((kount-1).eq.pklim) then
         write(6,'(a)') 'MAXITER reached !!!!!!!!'
         goto 1000
         endif
c   end after pklim iter
c     Interchange Rows if out is a coef
      if (abs(varb(out)).gt.nobs) then
      do 1350 j = kr,nx2
         d = wa(out,j)
         wa(out,j) = wa(kl,j)
         wa(kl,j) = d
 1350       continue
      di = varb(out)
      varb(out) = varb(kl)
      varb(kl) = di
      kl = kl + 1
      endif
c      write(6,'(2(a10,i6))') 'Kount = ',kount,' kl = ',kl
c     update if mod(kount,upfreq) = 0
      if (mod(kount,upfreq).eq.0) then
c      write(6,'(/,a,/,a,i6,a)') 
c     &   '***************************************',
c     &   'Tableau Update after ',kount,' iterations '
      call setuptabl(wa,varn,varb,xx,y,yc,beta,pr,prcens,cens,
     &                     nobs,nx,nobs1,nx2,kl,toler,theta)
      call tabcheck(xx,wa,varb,varn,nobs1,nobs,nx,nx2,toler)
      itabch = itabch + 1
      if (itabch.eq.pklim) goto 1000
c      write(6,*) 'Setuptable '
c      do 1360 j1 = 1,nx   
c         write(6,'(a,i3,a,f15.8)') 'beta(',j1,') = ',beta(j1)
c 1360       continue
c      write(6,'(/,a,f15.8,/)') 'Value of Objective : ',wa(nobs1,nx1)
      wa(nobs1,nx1) = big
c      do 1370 j1 = 1,nx   
c         write(6,'(i3,a,i10)') j1,
c     &            'th-Interpolated Observation = ',varn(j1)
c 1370       continue
c      write(6,*) ' '
      endif
c     end of update if mod(kount,upfreq) = 0      
c     Control Print of Tableau
c      call tabprint(wa,varb,varn,pr,prcens,z,nobs1,nobs,nx,nx2,
c     &              pkount,kl,cens)
c      if (pkount.eq.pklim) goto 1000
c     Control Print of Tableau
      go to 205
 1000 continue
      setuptable = 0
      RETURN
      END
      SUBROUTINE tabprint(wa,varb,varn,pr,prcens,z,nobs1,nobs,nx,nx2,
     &                    pkount,kl,cens)
      IMPLICIT REAL*8 (a-h,o-z)
      INTEGER nobs,nx,prcens(nobs),nx2,nobs1,nx1,cens(nobs)
      INTEGER i,j,varb(nobs),varn(nx),pkount,kl,b,e
      REAL*8 wa(nobs1,nx2),pr(nobs),z(nobs)
      CHARACTER out*74
      write(6,'(/,a,i6,/)') 'Tableau # ',pkount
      pkount = pkount + 1
      nx1 = nx + 1
      b = 7
      e = 15
      do 10 j = 1,74
         out(j:j) = ' '
 10      continue
      do 20 j = 1,nx
         if (varn(j).le.-nobs-1) then
            write(out(b:e),'(a,i1,a)') '   c(',abs(varn(j))-nobs,')'
            b = b + 8
            e = e + 8
         else if (varn(j).le.-1) then
            write(out(b:e),'(a,i1,a)') '   v(',abs(varn(j)),')'
            b = b + 8
            e = e + 8
         else if (varn(j).le.nobs) then
            write(out(b:e),'(a,i1,a)') '   u(',varn(j),')'
            b = b + 8
            e = e + 8
         else if (varn(j).le.nobs+nx) then
            write(out(b:e),'(a,i1,a)') '   b(',varn(j)-nobs,')'
            b = b + 8
            e = e + 8
         endif
 20      continue 
      write(out(b:74),'(3a8,2(a5,a8))') '  t(i,0) ','  t(i,c) ',
     &  '    R ',' VarB','  Pred ','Prcen',' Z'
      write(6,'(a)') out
      do 30 i = 1,kl-1
         out(1:40)  = '                                        '
         out(41:74) = '                                  '
         b = 1
         e = 6
         if (varb(i).le.-nobs-1) then
            write(out(b:e),'(a,i1,a)') 'c(',abs(varb(i))-nobs,')'
         else if (varb(i).le.-1) then
            write(out(b:e),'(a,i1,a)') 'v(',abs(varb(i)),')'
         else if (varb(i).le.nobs) then
            write(out(b:e),'(a,i1,a)') 'u(',varb(i),')'
         else if (varb(i).le.nobs+nx) then
            write(out(b:e),'(a,i1,a)') 'b(',varb(i)-nobs,')'
         endif
         b = b + 6
         write(out(b:74),'(10f8.3)') (wa(i,j),j=1,nx1)
         b = b + 8*nx2 
         write(out(b:74),'(8x,i5)') varb(i)
         write(6,'(a)') out
 30      continue
      do 40 i = kl,nobs
         do 50 j = 1,74
            out(j:j) = ' '
 50         continue
         b = 1
         e = 6
         if (varb(i).le.-nobs-1) then
            write(out(b:e),'(a,i1,a)') 'c(',abs(varb(i))-nobs,')'
         else if (varb(i).le.-1) then
            write(out(b:e),'(a,i1,a)') 'v(',abs(varb(i)),')'
         else if (varb(i).le.nobs) then
            write(out(b:e),'(a,i1,a)') 'u(',varb(i),')'
         else if (varb(i).le.nobs+nx) then
            write(out(b:e),'(a,i1,a)') 'b(',varb(i)-nobs,')'
         endif
         b = b + 6
         write(out(b:74),'(10f8.3)') (wa(i,j),j=1,nx2),
     &    abs(min(z(abs(varb(i))),-wa(i,nx1)*sign(1.d0,dble(varb(i)))))
         b = b + 8*nx2 + 8
         write(out(b:74),'(2(i5,f8.3))') 
     &     varb(i),pr(abs(varb(i))),prcens(abs(varb(i))),z(abs(varb(i)))
         write(6,'(a)') out
 40      continue
      write(6,'(/,a6,10f8.3)') 'MC ',(wa(nobs1,j),j=1,nx1)
      write(6,'(a6,2i8)')   'VarN',(varn(j),j=1,nx)
      write(6,'(a6,2i8)')   'Cens',(cens(abs(varn(j))),j=1,kl-1)
      write(6,'(a6,2i8,/)') 'Prcens',(prcens(abs(varn(j))),j=1,kl-1)
      RETURN
      END
      SUBROUTINE setuptabl(wa,varn,varb,xx,y,yc,beta,pr,prcens,cens,
     &                     nobs,nx,nobs1,nx2,kl,toler,theta)
      IMPLICIT REAL*8 (a-h,o-z)
      INTEGER nobs,nobs1,nx,nx2,i,j,ncoefp,l,mnobs,mnx1,mdim,idgt,kl
      REAL*8 zero,two,one,sum,theta,omtheta,r
      PARAMETER (mnobs=59820,mnx1=28,mdim=mnobs*mnx1,zero=0.d0,
     &           one=1.d0,two=2.d0,idgt = 6)
      REAL*8 wa(nobs1,nx2),xx(nobs,nx),y(nobs),yc(nobs),beta(nx),
     & wk(mdim),wa1(mdim),wa2(mdim),aa(mdim),toler,d,
     & m1(mdim),signum,pr(nobs),
     & wa3(mdim),determ8,eps,adet(mdim),lu(mdim),X02AJF
      INTEGER prcens(nobs),cens(nobs),var,di,thru(mnx1),
     & ier,varn(nx),varb(nobs),nuroind(mdim),nx1,crun,
     & id,ifail
      LOGICAL coef,varcens
      EXTERNAL mab8,f03aff,x02ajf,f04ahf
c     wk,wa1,wa2,aa,m1,nuroind are used as workspace
c      write(6,'(//,4(a45/),/)') 
c     & '*********************************************',
c     & '************** Set up Table *****************',
c     & '*********Varn  and  Varb given***************',
c     & '*********************************************'
c     VARN and VARB given
      nx1 = nx + 1
      omtheta = one - theta
c     Sort VARB such that coef's first and then residuals in increasing
c     order with observation number - important for matrix mult 
c     using nuroind(.)
      do 10 i = 1,nobs
         if (abs(varb(i)).gt.nobs) go to 10
         do 30 j = i,nobs
            if (abs(varb(j)).gt.nobs) then
               di = varb(j)
               varb(j) = varb(i)
               varb(i) = di
               go to 10
               endif
  30        continue          
  10     continue
      do 20 i = 1,nobs
         if (abs(varb(i)).gt.nobs) then
            varb(i) = abs(varb(i))
            go to 20
            endif
         do 40 j = i+1,nobs
            if (abs(varb(j)).lt.abs(varb(i))) then
               di = varb(j)
               varb(j) = varb(i)
               varb(i) = di
               endif
 40         continue
 20      continue
c     Sort VARN such that residuals in increasing order with 
c     observation number - important for matrix mult using nuroind(.)
      do 50 i = 1,nx
         do 60 j = i+1,nx
            if (abs(varn(j)).lt.abs(varn(i))) then
               di = varn(j)
               varn(j) = varn(i)
               varn(i) = di
               endif
 60         continue
 50      continue
      do 70 j = 1,nx
         varn(j) = abs(varn(j))
 70      continue
c     ncoefp is going to be the number of positive coef's in the basis
c     i.e. also the least number of points the fit will go thru         
      ncoefp = 0
      do 80 j = 1,nx
         var = abs(varn(j))
         if (var.le.nobs) then
            ncoefp = ncoefp + 1
            thru(ncoefp) = var
            endif
 80      continue
c     determine nuroind
      do 90 i = 1,nobs
         nuroind(i) = 0
 90      continue
      do 100 j = 1,nx
         if (abs(varn(j)).le.nobs) nuroind(abs(varn(j))) = 1
 100     continue
c     fill matrix and vector for linear equation
      do 110 j = 1,ncoefp
         var = abs(varb(j)) - nobs
         do 120 l = 1,ncoefp
c      Reprogram
c            wk((j-1)*ncoefp+l) = xx(thru(l),var)
            lu((j-1)*ncoefp+l) = xx(thru(l),var)
            adet((j-1)*ncoefp+l) = xx(thru(l),var)
c      End of Reprogram
 120        continue
 110     continue
c      Reprogram
c      call linv1f(wk,ncoefp,ncoefp,wa1,idgt,wa2,ier)
c      do 130 l = 1,ncoefp
c         wa2(l) = y(thru(l))
c 130     continue
c      call mab8(wa1,ncoefp,ncoefp,wa2,ncoefp,1,wk)
c      in NAG: i.e. solve wk*P = wa2 wrt P
      eps = X02AJF()
      ifail = 1
      call f03aff(ncoefp,eps,lu,ncoefp,determ8,id,wk,ifail)
      if (ifail.ne.0) write(6,'(a,i5)') 
     &     'Fehler in f03aff - ifail = ',ifail
      determ8 = determ8*(2.d0**dble(id))
      ifail = 1
c               call f04ahf(nx,1,adet,nx,lu,nx,workreal,ydet,nx,eps,
c     &                     savbeta,nx,wa,nx,l,IFAIL)
c      call f04ahf(ncoefp,1,adet,ncoefp,lu,ncoefp,wk,wa2,
c     &        ncoefp,eps,wa1,ncoefp,wa3,ncoefp,l,IFAIL)
      do l = 1,ncoefp
         do i = 1,ncoefp
            if (i.ne.l) then
               wa2((l-1)*ncoefp+i) = 0.d0
               else
               wa2((l-1)*ncoefp+i) = 1.d0
               endif
            enddo
         enddo
      call f04ahf(ncoefp,ncoefp,adet,ncoefp,lu,ncoefp,wk,wa2,
     &        ncoefp,eps,wa1,ncoefp,wa3,ncoefp,l,IFAIL)
      if (ifail.ne.0) write(6,'(a,i5)') 
     &     'Fehler in f04ahf - ifail = ',ifail
      do 130 l = 1,ncoefp
         wa2(l) = y(thru(l))
 130     continue
      call mab8(wa1,ncoefp,ncoefp,wa2,ncoefp,1,wk)
c
c     wk contains solution
c
c     end of NAG-Reprograming
      do 140 j = 1,nx
         beta(j) = zero
 140     continue
      do 150 j = 1,ncoefp
         beta(abs(varb(j))-nobs) = wk(j)
 150     continue
c     determine if regression line is above or below obs
      call mab8(xx,nobs,nx,beta,nx,1,pr)
c      call dgemul(xx,nobs,'N',beta,nx,'N',pr,
c     &            nobs,nobs,nx,1)
c     Determine Pr , Prcens, and column nx2 in WA
      do 160 i = ncoefp+1,nobs
         var = abs(varb(i))
         varb(i) = nint(sign(dble(varb(i)),y(var)-pr(var)))
         d = yc(var)-pr(var)
         wa(i,nx2) = sign(1.d0,y(var)-pr(var))*d
         if (d.gt.toler) then
            prcens(var) = 0
            else if (abs(d).le.toler) then
            prcens(var) = 1
            else if (d.lt.-toler) then
            prcens(var) = 2
            endif
 160     continue
      do 170 j = 1,nx
         var = abs(varn(j))
         if (var.le.nobs) then
            d = yc(var)-pr(var)
            if (d.gt.toler) then
               prcens(var) = 0
               else if (abs(d).le.toler) then
               prcens(var) = 1
               else
               prcens(var) = 2
               endif     
            endif
 170     continue
c     Put A^(-1) into M1
      do 180 j = 1,ncoefp
         do 190 i = 1,ncoefp
            m1(i+(j-1)*nobs) = wa1((j-1)*ncoefp+i)
 190        continue
 180     continue
c     Now wk stands for (nobs-ncoefp) x ncoefp matrix B
c     Put -D*B*A^(-1) into M1
      do 200 j = 1,ncoefp
         l = 0
         var = abs(varb(j)) - nobs
         do 210 i = 1,nobs
            if (nuroind(i).eq.0) then
               l = l + 1
               wk(l+(j-1)*(nobs-ncoefp)) = xx(i,var)
               endif
 210        continue
 200     continue
      call mab8(wk,nobs-ncoefp,ncoefp,wa1,ncoefp,ncoefp,wa2)
      l = 0
      do 220 i = 1,nobs
         if (abs(varb(i)).le.nobs) then
            l = l + 1
            do 230 j = 1,ncoefp
               m1(ncoefp+l+(j-1)*nobs) = -sign(1.d0,dble(varb(i)))
     &                     *wa2(l+(j-1)*(nobs-ncoefp))
 230           continue
            endif
 220     continue
c     AA is now filled with columns of NONBASIS variables and b==y
      do 300 j = 1,nx
         signum = sign(1.d0,dble(varn(j)))
         var = abs(varn(j))
         if (var.le.nobs) then
            do 310 i = 1,nobs
               aa(i+(j-1)*nobs) = zero
 310           continue
            aa(var+(j-1)*nobs) = signum
            else
            do 320 i = 1,nobs
               aa(i+(j-1)*nobs) = signum*xx(i,var-nobs)
 320           continue
            endif
 300     continue
      do 330 i = 1,nobs
         aa(i+(nx1-1)*nobs) = y(i)
 330     continue
c     Put part of AA into wa2 which is to be multiplied with M1
      l = 0
      do 340 i = 1,nobs
         if (nuroind(i).eq.1) then
            l = l + 1
            do 350 j = 1,nx1
               wa2(l+(j-1)*ncoefp) = aa(i+(j-1)*nobs) 
 350           continue
            endif
 340     continue
      call mab8(m1,nobs,ncoefp,wa2,ncoefp,nx1,wa1)
c     Take rows from AA for multiplication with D=D^(-1) into wa2
      do 360 i = 1,nobs*nx1
         wa2(i) = zero
 360     continue
c     l = ncoefp+1,...,nobs for product of D and AA
      l = ncoefp
      do 370 i = 1,nobs
c     signum is sign of diagonal element l-ncoefp in D
         if (nuroind(i).eq.0) then
            l = l + 1
            signum = sign(1.d0,dble(varb(l)))
            do 380 j = 1,nx1
               wa2(l+(j-1)*nobs) = signum*aa(i+(j-1)*nobs) 
 380           continue
            endif   
 370     continue
      do 390 j = 1,nx1
         do 400 i = 1,nobs
            wa(i,j) = wa1(i+(j-1)*nobs) + wa2(i+(j-1)*nobs)
 400        continue
 390     continue
c  Control Prints
c      write(6,'(/,a,/)') 'Print M1'
c      do 410 i = 1,nobs
c         write(6,'(4f8.3)') (m1(i+(j-1)*nobs),j=1,ncoefp)
c 410     continue
c      write(6,'(/,a,/)') 'Print AA'
c      do 420 i = 1,nobs
c         write(6,'(4f8.3)') (aa(i+(j-1)*nobs),j=1,nx1)
c 420     continue
c      write(6,'(/,a,/)') 'Print wa1'
c      do 430 i = 1,nobs
c         write(6,'(4f8.3)') (wa1(i+(j-1)*nobs),j=1,nx1)
c 430      continue
c      write(6,'(/,a,/)') 'Print wa2'
c      do 440 i = 1,nobs
c         write(6,'(4f8.3)') (wa2(i+(j-1)*nobs),j=1,nx1)
c 440     continue
c      write(6,'(/,a,/)') 'Print wa = wa1 + wa2'
c      do 450 i = 1,nobs
c         write(6,'(9f8.3)') (wa(i,j),j=1,nx2)
c 450     continue
c     end of print
      kl = ncoefp + 1
c     Calculate Value of objective
      sum = zero   
      do 45 i = kl,nobs
         var = abs(varb(i))
         sum = sum + r(theta,y(var)-min(pr(var),yc(var)))
 45      continue
      wa(nobs1,nx1) = sum
c     Calculate Marginal Cost - Stage Setup
      do 280 j = 1,nx
         var = abs(varn(j))
         if (var.gt.nobs) then
            coef = .true.
            else 
            coef = .false.
            endif
         crun = 0
 235     wa(nobs1,j) = zero
         do 240 i = kl,nobs
            if (prcens(abs(varb(i))).eq.2) goto 240
            var = varb(i)
            d = wa(i,j)
            if (prcens(abs(varb(i))).eq.0) goto 250
            if ((d.lt.-toler).and.(varb(i).gt.0)) then
               d = d*theta
               goto 260
               endif
            if ((d.gt.toler).and.(varb(i).lt.0)) goto 250
            goto 240
 250        if ((wa(i,nx1).lt.toler).and.(d.gt.zero)) then
               var = -var
               d = -d
               endif
            if (var.gt.0) then
               d = d*theta
               else
               d = d*omtheta
               endif
 260        wa(nobs1,j) = wa(nobs1,j) + d
c         write(6,'(a,i4,a,i2,a,f15.9)') 
c     &        'MCR ohne nb: wa(',nobs1,',',j,') = ',wa(nobs1,j)
 240        continue
      if (coef) goto 270
      if ((cens(var).eq.1).and.(varn(j).lt.0)) goto 270
      if (varn(j).gt.0) then 
         wa(nobs1,j) = wa(nobs1,j) - theta
         else 
         wa(nobs1,j) = wa(nobs1,j) - (one - theta)
         endif
c         write(6,'(a,i4,a,i2,a,f15.9)') 
c     &        'MCR: wa(',nobs1,',',j,') = ',wa(nobs1,j)
 270     if (crun.eq.1) goto 280
      crun = 1
c      if ( ((.not.coef).and.(wa(nobs1,j)+two.lt.toler)) .or.
c     &        ((     coef).and.(wa(nobs1,j)    .lt.toler)) ) then
      if ( ((.not.coef).and.(wa(nobs1,j)+one.lt.toler)) .or.
     &        ((     coef).and.(wa(nobs1,j)    .lt.toler)) ) then
c        Change sign in column b/c MC < 0 and MC of 
c              -varn(j) could be positive
         varn(j) = -varn(j)
         do 1310 i = 1,nobs
            wa(i,j) = -wa(i,j)
 1310       continue
         goto 235
         endif
 280     continue
      RETURN
      END
      SUBROUTINE tabcheck(xx,wa,varb,varn,nobs1,nobs,nx,nx2,toler)
      IMPLICIT REAL*8 (a-h,o-z)
      INTEGER nobs,nobs1,nx,nx1,nx2
      INTEGER i,j,varb(nobs),varn(nx),ii,jj,coefnum,errorco
      REAL*8 wa(nobs1,nx2),xx(nobs,nx2),lhs(30892),rhs(30892),
     & zero,one,factor,maxdiff,toler
      PARAMETER (zero=0.d0,one=1.d0)
c
c    Check if difference in lhs and rhs - lhs is vector associated with
c                                             nonbasis-variable or residuals
c                                         rhs is calculated vector from
c                                             basis-vectors and table entries
c      write(6,'(a,e15.4)') 'T A B C H E C K  -  Toler = ',toler
      errorco = 0
      do 10 j = 1,nx
c determine lhs
         if (abs(varn(j)).le.nobs) then
            do 20 i = 1,nobs
               lhs(i) = zero
 20            continue
            lhs(abs(varn(j))) = sign(one,dble(varn(j)))
            else
              coefnum = abs(varn(j)) - nobs
            do 30 i = 1,nobs
               lhs(i) = sign(one,dble(varn(j)))*xx(i,coefnum)
 30            continue
            endif
c determine rhs
         do 40 i = 1,nobs
            rhs(i) = zero
 40         continue
         do 50 ii = 1,nobs
            factor = wa(ii,j)
            if (abs(varb(ii)).le.nobs) then
               rhs(abs(varb(ii))) = rhs(abs(varb(ii))) + 
     &                            sign(one,dble(varb(ii)))*factor
               else
               coefnum = abs(varb(ii)) - nobs
               do 60 i = 1,nobs
                  rhs(i) = rhs(i) + 
     &                   sign(one,dble(varb(ii)))*xx(i,coefnum)*factor
 60               continue
            endif                   
 50         continue
         maxdiff = zero
         do 70 i = 1,nobs         
            if (abs(rhs(i)-lhs(i)).gt.maxdiff) 
     &         maxdiff = abs(rhs(i)-lhs(i))
 70         continue
         if (maxdiff.ge.toler) then
            write(6,'(a,i5,a,e15.4)')
     &      'Problem: Fuer VARN = ',varn(j),' Maxdiff = ',maxdiff
            errorco = 1
            endif
 10      continue
c      if (errorco.eq.0) write(6,'(/,a,/)') 
c     &   'T A B C H E C K finished successfully '
      if (errorco.eq.1) write(6,'(/,a,/)') 
     &   'T A B C H E C K problem'
      RETURN
      END
      REAL*8 FUNCTION r(theta,err)
      REAL*8 theta,err
      if (err .ge. 0) r = err*theta
      if (err .lt. 0) r = err*(theta-1.d0)
      RETURN
      END
      REAL*8 FUNCTION objective(y,yc,x,beta,nobs,nx,theta)
      INTEGER i,nobs,nx,j
      REAL*8 y(nobs),yc(nobs),x(nobs,nx),beta(nx),
     & theta,r,ypred
      EXTERNAL r
      objective = 0.d0
      do 10 i = 1,nobs
         ypred = 0.d0
         do j = 1,nx
            ypred = ypred + x(i,j)*beta(j)
            enddo
         if (yc(i).gt.ypred) then 
            objective = objective
     &             + r(theta,y(i)-min(ypred,yc(i)))
            else
            objective = objective
     &             + (1.d0-theta)*(yc(i)-y(i))
            endif
 10      continue
      RETURN
      END
      FUNCTION bincoef(n,k)
      REAL*8 one,lgamma
      EXTERNAL lgamma
      PARAMETER (one = 1.d0)
      bincoef = exp(lgamma(n + one) - lgamma(k + one) 
     &          - lgamma(n-k + one))
      RETURN
      END

