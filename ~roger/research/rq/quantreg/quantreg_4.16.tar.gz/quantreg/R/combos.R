"combos" <- function(n,p){
	m <- choose(n,p)
	z <- .Fortran("combin",
		as.integer(n),
		as.integer(p),
		as.integer(m),
		a = integer(p*m),
		integer(n),
		integer(n),
		integer(n),
		PACKAGE = "quantreg")
	matrix(z$a,p)
	}
