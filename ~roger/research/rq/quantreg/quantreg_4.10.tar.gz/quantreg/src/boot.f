C Output from Public domain Ratfor, version 1.0
      subroutine rqs(m,n,k,m5,n2,a,b,t,toler,ift,x,e,s, wa,wb,nsol,sol,d
     *sol,lsol)
      double precision b(m,k),sol(n2,nsol),a(m,n),x(n,k)
      double precision wa(m5,n2),wb(m),e(m),dsol(m,nsol)
      double precision t,toler
      integer m,n,k,m5,n2,ift,nsol,lsol
      integer s(m)
      do23000 i=1,k
      call rq1(m,n,m5,n2,a,b(1,i),t,toler,ift,x(1,i),e,s, wa,wb,nsol,sol
     *,dsol,lsol)
23000 continue
23001 continue
      return
      end
      subroutine pwy(m,n,k,m5,n2,a,c,b,t,toler,ift,x,e,s, wa,wb,nsol,sol
     *,dsol,lsol)
      double precision b(m),sol(n2,nsol),a(k,n),x(n,k)
      double precision wa(m5,n2),wb(m),e(m),dsol(m,nsol),c(m,n)
      double precision t,toler
      integer m,n,k,m5,n2,ift,nsol,lsol
      integer s(m)
      do23002 i=1,k
      call dcopy(n,a(i,1),k,c(m,1),m)
      call rq1(m,n,m5,n2,c,b,t,toler,ift,x(1,i),e,s,wa,wb,nsol,sol,dsol,
     *lsol)
23002 continue
23003 continue
      return
      end
      subroutine xys(mofn,m,n,k,mofn5,n2,a,b,tau,toler,ift,x,e,s, wa,wb,
     *nsol,sol,dsol,lsol,aa,bb,ss)
      double precision b(m),sol(n2,nsol),a(m,n),x(n,k),double precision 
     *wa(mofn5,n2),wb(mofn)
      double precision aa(mofn,n),bb(mofn),e(mofn),dsol(mofn,nsol)
      double precision tau,toler
      integer ss(mofn,k),s(mofn),mofn,m,n,k,mofn5,nsol,lsol,ift(k)
      do23004 i=1,k 
      do23006 ii=1,mofn
      bb(ii)=b(ss(ii,i))
      do23008 jj=1,n
      aa(ii,jj)=a(ss(ii,i),jj)
23008 continue
23009 continue
23006 continue
23007 continue
      call rq1(mofn,n,mofn5,n2,aa,bb,tau,toler,ift(i),x(1,i),e,s,wa,wb,n
     *sol,sol,dsol,lsol)
23004 continue
23005 continue
      return
      end
      subroutine heqfy(n,p,r,x,b,y)
      integer n,p,r
      double precision x(n,p),b(p,n,r),y(n,r)
      do23010 i=1,r
      do23012 j=1,n
      y(j,i)=ddot(p,x(j,1),n,b(1,j,i),1)
23012 continue
23013 continue
23010 continue
23011 continue
      return
      end
