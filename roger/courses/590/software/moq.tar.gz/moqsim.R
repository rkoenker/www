# Simulation experiment of  MoQ fitting 
#
# True quantile function (RFD (17) with X_3 = s_1 = s_2 = .5 )
Qtrue <- function(t) 1 + (t+1) * qnorm(t) + (5/4) * t^2

Bernstein <- function(u,M)dbinom(1:M - 1, M-1,u)
BernsteinBasis <- function(u,M) t(sapply(u,Bernstein, M = 10))

# Summary function for ordinary sample quantiles
qsum <- function(y,taus){
	require(quantreg)
	n <- length(y)
	f <- lapply(summary(rq(y ~ 1, tau = taus),se = "iid"),coefficients)
	f <- matrix(unlist(f),4)
	b <- f[1,]
	Vb <- f[2,]^2
	Omega <- outer(taus,taus,"pmin") - outer(taus,taus) # Brownian Bridge 
	f <- sqrt(diag(Omega)/(n * Vb)) # Density estimates
	V <- Omega/(n * outer(f,f)) # Avar(b)
	H <- backsolve(chol(V),diag(length(taus))) # Cholesky Factor for V^{-1}
	list(b = b, Vb = Vb, H = H)
}
# MoQ Regression 
moq.fit <- function(X, y, H){
	# V is Cholesky factors  for the Likelihood 
	X <- H %*% X
	y <- H %*% y
	f <- lm(y ~ X - 1)
	list(coef = coef(f), vcov = vcov(f))
	}

# Constrained MoQ estimate of Bernstein coefficients
cmoq.fit <- function(X, y, H, lambda = .1){
        require(mgcv) # For pcls
        n <- length(y)
        p <- ncol(X)
	X <- H %*% X
	y <- H %*% y
        S <- rbind(c(1,rep(0,p-1)),diff(diag(p)))
        C <- matrix(0,0,0) # See Ex1 of ?pcls
        pinit <- 1:p/(p+1) # Needs to strictly satisfy the constraints
        Ain <- diff(diag(p))
        bin <- rep(0,p-1)
        M <- list(y = y, X = X, w = rep(1,n), S = list(S), p = pinit,
                off = 0, C = C, sp = lambda, Ain = Ain, bin=bin)
        pcls(M)
        }


set.seed(1900)
R <- 10000
K <- 19
n <- 101
taus <- 1:K/(K+1) # see p15 of RFD (?)
A <- array(0, c(K,3,R))
for(i in 1:R){
	y <- Qtrue(runif(n))
	g <- qsum(y,taus)
	X <- BernsteinBasis(taus,M)
	h <- moq.fit(X,g$b,g$H)
	ch <- cmoq.fit(X,g$b,g$H)
	A[,1,i] <- g$b
	A[,2,i] <- X %*% h$coef
	A[,3,i] <- X %*% ch
	}
