load("moqsim.Rda")
Qtrue <- function(t) 1 + (t+1) * qnorm(t) + (5/4) * t^2
K <- 19
taus <- 1:K/(K+1)
Qt <- Qtrue(taus)
B <- sqrt(apply((A - Qt)^2,1:2,mean))
pdf(file = "moqrmse.pdf", height = 4, width = 6)
matplot(taus, B, lwd = 2, type = "l", xlab = expression(tau), ylab = "RMSE")
legend(0.1,0.5,c("OSQ","MoQ","CMoQ"),lwd = rep(2,3), lty = 1:3,col = 1:3)
dev.off()
B <- apply((A - Qt),1:2,mean)
pdf(file = "moqbias.pdf", height = 4, width = 6)
matplot(taus, B, lwd = 2, type = "l", xlab = expression(tau), ylab = "Bias")
abline(h = 0, lwd = 2)
legend(0.1,-0.1,c("OSQ","MoQ","CMoQ"),lwd = rep(2,3), lty = 1:3,col = 1:3)
dev.off()

