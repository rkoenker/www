# Figure 1 for MOQ notes
Bernstein <- function(u,M)dbinom(1:M - 1, M-1,u)
BernsteinBasis <- function(u,M) t(sapply(u,Bernstein, M = 10))
pdf(file = "moq1.pdf", height = 4, width = 7)
u <- 1:999/1000;  matplot(u, BernsteinBasis(u), type = "l")
dev.off()

