# Figure 2 for MOQ notes
Bernstein <- function(u,M)dbinom(1:M - 1, M-1,u)
BernsteinBasis <- function(u,M) t(sapply(u,Bernstein, M = 10))
pdf(file = "moq2.pdf", height = 4, width = 7)
par(mfrow = c(1,2))
u <- 1:999/1000
qrfd <- function(t) 1 + (t+1) * qnorm(t) + (5/4) * t^2
matplot(u,cbind(qnorm(u), qrfd(u)),type = "l", 
		xlab = expression(tau), ylab = expression(q( tau)))
drfd <- function(t) 1/((t+1)/dnorm(qnorm(t)) + qnorm(t) + (10/4) * t)
plot(qnorm(u), dnorm(qnorm(u)),type = "l", xlim = c(-4, 10), 
		ylim = c(0, 1/sqrt(2*pi)), xlab = "x", ylab = "f(x)")
lines(qrfd(u), drfd(u), lty = 2, col = "red")
dev.off()

