# TV(g)
require(quantreg)
source("conformal.R")
pdf("TV0.pdf", height = 6, width = 6)
plot(x,y, cex = .25, ylim = c(-2,6), col = 'grey')
newx = seq(0,5,by = 0.05)
f = conformal(y ~ qss(x,lambda = .05, Dorder = 0), split = 2/7, data = D, newdata = list(x = newx))
plot(f$qlo, add = TRUE, titles = "", rug = FALSE, col = 2, lwd = 3)
plot(f$qhi, add = TRUE, titles = "", col = 2, rug = FALSE, lwd = 3)

lines(newx, f$pred[,1], col = 4)
lines(newx, f$pred[,2], col = 4)
dev.off()

