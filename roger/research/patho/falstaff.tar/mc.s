#Monte-Carlo comparison of the Falstaff Location Estimator
#dyn.load("swindle.o")
#dyn.load3("solve.o")
dyn.load("falstaff.o")
#for ragnar I use (thanks to Pin)
#	ld -r -dn -o falstaff.o solve.o swindle.o -L/usr/local/lib -lSport
options(object.size=9e6)
seed_.Random.seed
R_10000				#number of replications
ns_c(10,15,25,50,75,100)	#sample sizes
ps_c(1:8)			#dimension of pseudo design component
dfs_c(1,3,5)			#degrees of freedom of the t density
nns_length(ns)
ndfs_length(dfs)
nps_length(ps)
mse_array(0,dim=c(nns,nps+2,ndfs))
mae_array(0,dim=c(nns,nps+2,ndfs))
vse_array(0,dim=c(nns,nps+2,ndfs))
vae_array(0,dim=c(nns,nps+2,ndfs))
for(i in 1:nns){
   for(j in 1:ndfs){
	print(i)
	n_ns[i]
	df_dfs[j]
	y_swindle(n,R,df)
	mean.y_c(t(y)%*%rep(1,n)/n)
	med.y_apply(y,2,"median")
	fal.y_matrix(0,nps,R)
     for(k in 1:nps){
	p_ps[k]
	Z_ matrix(rnorm(n*p),n,p)
	fal.y[k,]_Falstaff(y,Z)
	}
	M_rbind(mean.y,fal.y,med.y)
	mse[i,,j]_apply(M^2,1,"mean")
	vse[i,,j]_apply(M^2,1,"var")
	         }
	}
#dimnames(mse.sum)_list(paste("n=",ns),
#	c("mean","median","falstaff"))
#dimnames(mae.sum)_list(paste("n=",ns),
#	c("mean","median","falstaff"))

