# Flower plot for exv3 example
load("exv3.Rda")
pdf("fig2exv3.pdf",height = 4, width = 6)
levels <- c(-.55, -.5, 0, 0.5, 1, 2, 3, 3.05, 3.1)
contour(ya,yv,D,levels = levels, method = "edge", 
	xlab = expression(bar(y)), ylab = "S")
#rug(a, col = 3)
points(a,s,cex = .5,col = "grey")
dev.off()
