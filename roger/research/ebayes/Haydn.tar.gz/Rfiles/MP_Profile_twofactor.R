require(REBayes)
require(foreign)


source("profl_fun.R")


source("MP_DataProcess2.R")

rhos = seq(0.40,0.60,length=11)
LogLik <- rep(0,length(rhos))
Diag <- rep(0, length(rhos))
Diag2 <- matrix(0,2,length(rhos))
fmix <- matrix(0,3600,length(rhos))
fu <- matrix(0,60,length(rhos))
fv = matrix(0,60,length(rhos))
for (k in 1:length(rhos)){
dif = tapply(psid$ystand,psid$id,pardiff,rho = rhos[k])

psid$AR <- unlist(dif)

y = psid$AR
id = psid$id
A = cbind(y,id)
A = A[!is.na(y),]
y = A[,1]
id = A[,2]
w = rep(1,length(y))
f = WGLVmix(y,id,w,pu = 60, pv = 60, rtol = 1e-11,verb = 5)
LogLik[k] <- LikGLVmixbi(f,y,id,w)
Diag[k] <- f$flag
Diag2[,k] = range(f$fuv)
fmix[,k] = f$fuv
fu[,k] = f$u
fv[,k] = f$v
print(k)
}


save.image("MP_Profile_twofactor.Rda")
