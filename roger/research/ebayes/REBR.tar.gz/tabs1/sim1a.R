# compare risk of for G_0 ~ N(0,1) for the standard Gaussian sequence model
require(Hmisc)
load("sim1.Rda")
A <- apply(Risk[2,,,,], 1:3, mean)
A <- matrix(A, 12, 8)
cnames <- c("MLE", "$\\delta^B$", "$\\hat \\delta^B$", "$\\delta_{\\hat G}^B$",
	    "$\\delta^H$", "$\\delta^M$", "$\\delta_{\\hat G}^H$", "$\\delta_{\\hat G}^M$") 
rgroup <- paste("n = ", ns)
rnames <- rep(paste("$\\epsilon = $", kappas),length(ns))
dimnames(A) <- list(rnames, cnames)
cap <- c("Mean squared error for several compound decision rules. 
	 Data generated as $Y = \\mu + U$ with $\\mu \\sim \\NN (0,1)$ and
	 $U \\sim \\NN (0,1)$, and initial prior is $G_0 = \\NN (0,1)$.")
latex(A, digits = 3, rgroup = rgroup, rowlabel = "", caption = cap, 
      caption.loc = "bottom", label = "tab.sim1a", file = "sim1a.tex")
