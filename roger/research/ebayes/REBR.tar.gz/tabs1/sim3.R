# simulation to compare Efron-Morris vs. Hodges-Lehman with G = {-B, B} with equal prob.
# 
require(REBayes)
Bs <- 1:3
kappas <- c(0.05, 0.1, 0.2, 0.4) 
R <- 500
ns <- c(100,500,1000)
a <- 30
grid <- seq(-a,a,length = 2500)
gridv <- seq(-16,16,by = 0.02)
Risk <- array(NA, c(length(Bs), length(kappas), length(ns), 9, R)) 
sessionInfo()
set.seed(782)
for (j in 1:length(Bs)){
    B <- Bs[j]
    for (k in 1:length(kappas)){
	S <- (gridv==B|gridv==-B)
	G0 = rep(0, length(gridv))
	G0[S] = 1/(sum(S))
	G <- list(x = gridv, y = G0)
	Valpha <- B^2
	Malpha <- 0
	fg=dnorm(gridv, mean = Malpha, sd = sqrt(Valpha))
	GG <- list(x = gridv, y = fg/sum(fg))
	f1 <- HodgesLehmann(grid, GG, alpha = 1-kappas[k])
	f0 <- HodgesLehmann(grid, G, alpha = 1-kappas[k])
	f2 <- HodgesLehmann(grid, G, alpha = 1-kappas[k], type="Mallows")
	d0 <- f0$x[-1]+diff(log(f0$y))/diff(f0$x)
	d1 <- f1$x[-1]+diff(log(f1$y))/diff(f1$x)
	d2 <- f2$x[-1]+diff(log(f2$y))/diff(f2$x)
	d0f <- approxfun(f0$x[-1],d0)
	d1f <- approxfun(f1$x[-1], d1)
	d2f <- approxfun(f2$x[-1], d2)
	for (s in 1:length(ns)){
	    for (r in 1:R){
		theta <- sample(c(B, -B), ns[s], replace=TRUE)
		y <- theta + rnorm(ns[s])
		yB <- B*tanh(B*y)
		yBL <- Malpha  + Valpha * (y-Malpha) / (1+Valpha)
		Ghat <- GLmix(y, v = gridv,rtol = 1e-12)
		yBhat <- Ghat$dy
		f3 <- HodgesLehmann(grid, Ghat, alpha = 1-kappas[k])
		f4 <- HodgesLehmann(grid, Ghat, alpha = 1-kappas[k], type="Mallows")
		d3 <- f3$x[-1]+diff(log(f3$y))/diff(f3$x)
		d4 <- f4$x[-1]+diff(log(f4$y))/diff(f4$x)
		d3f <- approxfun(f3$x[-1],d3)
		d4f <- approxfun(f4$x[-1],d4)
		Risk[j,k,s,1,r] = mean((y-theta)^2)
		Risk[j,k,s,2,r] = mean((yBL-theta)^2)
		Risk[j,k,s,3,r] = mean((yB-theta)^2)
		Risk[j,k,s,4,r] = mean((yBhat-theta)^2)
		Risk[j,k,s,5,r] = mean((d1f(y)-theta)^2)
		Risk[j,k,s,6,r] = mean((d0f(y)-theta)^2)
		Risk[j,k,s,7,r] = mean((d2f(y)-theta)^2)
		Risk[j,k,s,8,r] = mean((d3f(y)-theta)^2)
		Risk[j,k,s,9,r] = mean((d4f(y)-theta)^2)
	  }
      print(s)
	}
    print(k)
    }
  print(j)
}


