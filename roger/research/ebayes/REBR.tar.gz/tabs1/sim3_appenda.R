# compare worst case point wise risk for different epsilon for G_0 ~ N(0,1) for the standard Gaussian sequence model
require(Hmisc)
load("sim3_appen.Rda")
A <- apply(Bound[2,,,,], 1:3, mean)
A <- matrix(A, 12, 4)
cnames <- c("Huber-G0", "Mallows-G0", "Huber-Ghat", "Mallows-Ghat") 
rgroup <- paste("n = ", ns)
rnames <- rep(paste("$\\epsilon = $", kappas),length(ns))
dimnames(A) <- list(rnames, cnames)
cap <- c("Worst case pointwise risk for various $\\epsilon$, 
	 $G_0 = 0.5 \\delta_{-2} + 0.5 \\delta_2$ and various sample sizes")
latex(A, digits = 3, rgroup = rgroup, rowlabel = "", caption = cap, 
      caption.loc = "bottom", label = "tab.sim3a_appendix", file = "sim3_appena.tex")
