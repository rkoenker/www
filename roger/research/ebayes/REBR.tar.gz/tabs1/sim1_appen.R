# Appendix to sim1.R G0 = N(0,A)
# calculate worst case pointwise risk of Mallows and EBMallows and Huber and EBHuber

require(REBayes)
sessionInfo()
set.seed(782)
Valphas <- c(0.5,1,2)
kappas <- c(0.05, 0.1, 0.2, 0.4) # contamination: larger kappas, more restrictions on the Bayes rule.
R <- 500
ns <- c(100,500,1000)
a <- 30
grid <- seq(-a,a,length = 2500)
gridv <- seq(-16,16,by = 0.02)

Risk <- array(NA, c(length(Valphas), length(kappas), length(ns), 8, R)) 
Bound <- array(NA, c(length(Valphas), length(kappas), length(ns), 4,R)) # oracle Huber and Mallow, eb Huber and Mallow
# compare risk of 
#	1) MLE, 
#	2) Linear Bayes rule, 
#	3) estimated linear rule 
#	4) KW rule 
#	5) HL rule Huber, aka Efron-Morris
#	6) HL rule Mallows 
#	7) HL Huber with NPMLE Ghat
#	8) HL Mallows with NPMLE Ghat
for (j in 1:length(Valphas)){
    for (k in 1:length(kappas)){
	G <- list(x = gridv, y = dnorm(gridv, mean = 0, sd = sqrt(Valphas[j])))
	G0 <- list(x = gridv, y = G$y/sum(G$y))
	G1 <- HodgesLehmann(grid, G0, alpha = 1-kappas[k])
	G2 <- HodgesLehmann(grid, G0, alpha = 1-kappas[k], type="Mallows")
	d1 <- G1$x[-1]+diff(log(G1$y))/diff(G1$x)
	d1f <- approxfun(G1$x[-1],d1)
	d2 <- G2$x[-1]+diff(log(G2$y))/diff(G2$x)
	d2f <- approxfun(G2$x[-1], d2)
	# compute worst case pointwise risk for Mallows rule 
	gridrepresent <- gridv[which.max(G2$H)]
	b_est <- function(rule, theta, N = 1e5){
		x <- rnorm(N, theta, 1)
		mean((rule(x)-theta)^2)
		}
	bound_M0 <- mean(replicate(50, b_est(d2f, gridrepresent, N = 1e5)))
	# compute worst case pointwise risk for Huber rule
	bound_H0 <- 1+(max(G1$d-G1$x))^2
	Bound[j, k, ,2,] = bound_M0
	Bound[j, k, ,1,] = bound_H0
    for (s in 1:length(ns)){
      for (r in 1:R){
        theta <- rnorm(ns[s], mean = 0, sd = sqrt(Valphas[j]))
        y <- theta + rnorm(ns[s])
        Malpha <- 0
        yB <- Malpha  + Valphas[j] * (y-Malpha) / (1+Valphas[j])
        Malphahat <- mean(y)
        Valphahat <- var(y)-1
        yBhat1 <- Malphahat + Valphahat * (y - Malphahat)/(1+Valphahat)
        Ghat <- GLmix(y, v = gridv)
        yBhat2 <- Ghat$dy
        G3 <- HodgesLehmann(grid, Ghat, alpha = 1-kappas[k])
        G4 <- HodgesLehmann(grid, Ghat, alpha = 1-kappas[k], type="Mallows")
        d3 <- G3$x[-1]+diff(log(G3$y))/diff(G3$x)
        d4 <- G4$x[-1]+diff(log(G4$y))/diff(G4$x)
        d3f <- approxfun(G3$x[-1],d3)
        d4f <- approxfun(G4$x[-1],d4)
        
        Bound[j, k,s ,4,r] = mean(replicate(50, b_est(d4f, gridv[which.max(G4$H)], N = 1e5)))
        Bound[j,k,s,3,r] = 1+(max(G3$d-G3$x))^2
        Risk[j,k,s,1,r] = mean((y-theta)^2) 
        Risk[j,k,s,2,r] = mean((yB-theta)^2) 
        Risk[j,k,s,3,r] = mean((yBhat1-theta)^2)
        Risk[j,k,s,4,r] = mean((yBhat2-theta)^2)
        Risk[j,k,s,5,r] = mean((d1f(y)-theta)^2)
        Risk[j,k,s,6,r] = mean((d2f(y)-theta)^2)
        Risk[j,k,s,7,r] = mean((d3f(y)-theta)^2)
        Risk[j,k,s,8,r] = mean((d4f(y)-theta)^2)
      }
      print(paste("s=",s))
    }
    print(paste("k=",k))
    }
  print(paste("j=", j))
}


