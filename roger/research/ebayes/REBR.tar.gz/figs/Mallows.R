###  Minimal Fisher (location) information via conic optimization
###  Mallows's Problem 78.4
###
###           ( f_{i+1}-f_i )^2       u_i^2
###   min sum ----------------- = sum -----  ~> I(F)
###           ( f_{i+1}+f_i )/2       v_i/2
###
###              <=>    min sum w_i  when u_i^2 <= 2 v_i w_i
###
###   subject to f = phi * g, g(-x) = g(x), for all x !=0, g(0) = alpha \in [0,1]
###
###   vars:     f    u    v    w   g
###   lengths:  m   m-1  m-1  m-1  p
###
###   When the grid is not equispaced, one would have to include grid spacings.


Mallows <- function(grid, gridg, alpha, ...){
  require(Rmosek)
  m <- length(grid)
  p <- length(gridg)
  n <- (p - 1)/2
  dots <- list(...)
  rtol <- ifelse(length(dots$rtol), dots$rtol, 1e-06)
  verb <- ifelse(length(dots$verb), dots$verb, 0)
  G <- cbind(spMatrix(n, 4*m-3), Diagonal(n), spMatrix(n, 1), 
	sparseMatrix( i = 1:n, j = n:1, x = rep(-1, n), dims = c(n, n)))
  A = cbind(Diagonal(m), spMatrix(m, 3*m-3), -dnorm(outer(grid, gridg, "-")))
  P <- list()
  P$sense <- "min"
  P$c <- c(rep(0,3*m-2), rep(1,m-1), rep(0, p))
  P$A <- rbind(A, G, 
    c(rep(0, 4*m-3), rep(0, n), 1, rep(0, n)),
    c(rep(0, 4*m-3), rep(1, p)),
    cbind(diff(Diagonal(m)), -Diagonal(m-1), spMatrix(m-1,2*m-2+p)),  
    cbind(abs(diff(Diagonal(m))), spMatrix(m-1,m-1), -Diagonal(m-1),
          spMatrix(m-1,m-1+p)))
  lhs <- c(rep(0, m), rep(0, n), alpha, 1, rep(0, 2*m-2))
  P$bc <- rbind(lhs,lhs)   
  P$bx <- rbind(c(rep(0,m),rep(-Inf,m-1),rep(0,2*m-2),  rep(0, p)),
          c(rep(Inf,4*m-3+p)))
  js = cbind((2*m-1)+(1:(m-1)), (3*m-2)+(1:(m-1)), m+(1:(m-1)))               
  P$F = sparseMatrix(i = 1:(3*(m-1)), j = c(t(js)), 
          x = rep(1, 3*(m-1)), dims = c(3*(m-1), 4*m-3+p))
  P$g = c(rep(0, 3*(m-1)))
  P$cones <-  matrix(list(),nrow=3,ncol=m-1)
  rownames(P$cones) = c("type", "dim", "conepar")
  for (k in 1:(m-1))
    P$cones[,k] <- list("RQUAD", 3, NULL)
  P$dparam$intpnt_co_tol_rel_gap <- rtol
  res <- Rmosek::mosek(P, opts = list(verbose = verb))
  z <- list(x = grid, y = res$sol$itr$xx[1:m], 
	    v = gridg, g = res$sol$itr$xx[-c(1:(4*m-3))])
  class(z) <- "density"
  return(z)
}

collapse <- function(f, eps = 0.001){
    # kludgy aggregation of neighboring mass points
    # beware:  presumes at most two neighbors
    z <- rle(f$g > eps)$lengths
    s <- cumsum(z)
    t <- s[z == 2] - 1
    for(i in 1:length(t)){
	f$g[t[i]] <- sum(f$g[t[i]:(t[i]+1)]) 
	f$g[t[i]+1] <- 0
    }
    f
}

require(Matrix)
pdf("Mallows.pdf", width = 9, height = 4)
par(mfrow = c(1,3))
a = 30
b = 20
grid = seq(-a,a,length = 500)
gridg = c(seq(-b, 0.01, by = 0.01), 0, seq(0.01, b, by = 0.01))
f1 <- Mallows(grid, gridg, alpha = 0.2, rtol = 1e-10)
f1 <- collapse(f1)
plot(f1$x, f1$y, type="l", main = "Marginal density", xlab = "x", ylab = "f(x)")
plot(f1$v, f1$g, type="l", main = "Mixing Distribution", xlab = "x", ylab = "g(x)")
x <- f1$v[f1$g > .001]
y <- f1$g[f1$g > .001]
x <- x[14:25]
y <- y[14:25]
plot(x,log(y), main = "Is it exponential?", xlab = "x", ylab = "log g(x)")
abline(lm(log(y)~x))
dev.off()
