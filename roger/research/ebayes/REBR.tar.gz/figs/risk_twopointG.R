# X|theta ~ N(theta,1)
# theta ~ 0.5 delta_{2} + 0.5 delta_{-2}, two point G
# E[theta|x] = 2 tanh(2x). 
# numerically integral to evaluate E[(2tanh(2x) - theta)^2] = \int (2tanh(2x)-theta)^2 dnorm(x, theta,1) dx 

library(stats)

# Define the integrand for fixed theta
risk_theta <- function(theta, lower=-Inf, upper=Inf) {
  integrand <- function(x) {
    fx_theta <- dnorm(x, mean = theta, sd = 1)
    loss <- (2 * tanh(2 * x) - theta)^2
    loss * fx_theta
  }
  integrate(integrand, lower = lower, upper = upper)$value
}


require(REBayes)
grid <- seq(-60,60, length = 5000)
gridv <- seq(-20,20, by = 0.01)
G <- list(x = gridv, y = rep(0, length(gridv)))
G$y[which(gridv==2 | gridv== -2)] = 1/2
fh <- HodgesLehmann(grid, G, alpha = 0.8)
fm <- HodgesLehmann(grid,G,alpha = 0.8, type="Mallows")
dh <- approxfun(grid, fh$d)
dm <- approxfun(grid,fm$d)

risk_theta_res <- function(theta, rule, lower = -Inf, upper = Inf) {
  integrand <- function(x) {
    fx_theta <- dnorm(x, mean = theta, sd = 1)
    loss <- (rule(x) - theta)^2
    loss * fx_theta
  }
  integrate(integrand, lower = lower, upper = upper)$value
}

# Grid of theta values
theta_grid <- seq(-10, 10, by = 0.01)

# Compute risk for each theta
risk_values <- sapply(theta_grid, risk_theta)

risk_values_resH <- sapply(theta_grid, risk_theta_res, rule = dh, lower = -30, upper = 30)
risk_values_resM <- sapply(theta_grid, risk_theta_res, rule = dm, lower = -25, upper = 25)


# estimate uniform risk bound: Stein's Lemma + Hodges and Lehmann result leads to evaluation 
# of E_H((theta - rule(x))^2) = -1+E_H[(x-rule(x))^] + 2E_H[rule'(x)]

# newTprime = diff(d1)/diff(yy)
# newTD = approxfun(yy[-1], newTprime) # gives derivative of delta^M

worst_risk <- function(f){
	r <- approxfun(f$x, f$d)
	r_prime <- diff(f$d)/diff(f$x)
	#r_prime <- approxfun(f$x[-1], r_prime)
	-1 + sum((f$x-f$d)^2 * f$h) + 2*sum(r_prime * f$h[-1])
	}
		


pdf("risk_twopointG.pdf")
plot(theta_grid, risk_values, type="l", lwd = 2,
     xlab=expression(theta), ylab=expression(R(theta)), ylim = c(0, 4))
     abline(h = 1, lty = 2)
lines(theta_grid, risk_values_resH,col=2, lwd = 2,)
lines(theta_grid, risk_values_resM,col=4, lwd = 2,)
legend("topleft", c("Bayes","Huber","Mallows"), col=c(1,2,4),lty = c(1,1,1), lwd = 2,)
rug(c(2,-2))
dev.off()
     
 f0 <- function(x) 0.5 * dnorm(x - 2) + 0.5 * dnorm(x + 2)

  # derivative: d/dx dnorm(x-m) = -(x-m) dnorm(x-m)
  f0p <- function(x) 0.5 * (-(x - 2)) * dnorm(x - 2) + 0.5 * (-(x + 2)) * dnorm(x + 2)

  logf0p <- function(x) f0p(x) / f0(x)
     
pdf("rule_twopointG.pdf")
ys <- seq(-10,10, by = 0.01)
plot( ys, ys + logf0p(ys), type="l",ylim = c(-10,10), xlab ="x", ylab = expression(d(x)), lwd = 2)
lines(ys, dh(ys), col = 2, lwd = 2)
lines(ys, dm(ys), col = 4, lwd = 2)
abline(c(0,1), lty = 2, col = "grey", lwd = 2)
legend("topleft", c("Bayes","Huber","Mallows"), col = c(1,2,4), lty = c(1,1,1),lwd = 2)
dev.off()   
   
     
