require(REBayes)

a <- 10
grid <- seq(-a, a, length = 501)
y <- dnorm(grid, sd = 1)
G <- list(x = grid, y = y/sum(y))
f0 <- HodgesLehmann(grid, G, alpha = 0.4, rtol = 1e-10)
f1 <- HodgesLehmann(grid, G, alpha = 0.4, type = "Mallows", rtol = 1e-10)

d1 <- f1$x[-1]+diff(log(f1$y))/diff(f1$x)
d0 <- f0$x[-1]+diff(log(f0$y))/diff(f0$x)

d1f <- approxfun(f1$x[-1], d1)
d0f <- approxfun(f0$x[-1],d0)

newy <- seq(-2,2,by = 0.01)
pdf("gauss.pdf")
plot(newy, d1f(newy), type="l", xlab = "x", ylab = "d(x)", lwd = 2)
lines(newy, d0f(newy), col = 2, lwd = 2)
abline(c(0,1), lty = 3, lwd = 2)
legend("topleft", c("Huber", "Mallows", "MLE"), lty = c(1,1,3), col = c(2,1,1), lwd = 2)
dev.off()

