# X|theta ~ N(theta,1)
# theta ~ 0.5 delta_{1} + 0.5 delta_{-1}, two point G
# E[theta|x] = tanh(x). 
# numerically integral to evaluate E[(2tanh(2x) - theta)^2] = \int (2tanh(2x)-theta)^2 dnorm(x, theta,1) dx 
# restrict theta \in [-1,1] as in Casella and Strawderman (1981). 

library(stats)

# Define the integrand for fixed theta
risk_theta <- function(theta, lower=-Inf, upper=Inf) {
  integrand <- function(x) {
    fx_theta <- dnorm(x, mean = theta, sd = 1)
    loss <- (1 * tanh(1 * x) - theta)^2
    loss * fx_theta
  }
  integrate(integrand, lower = lower, upper = upper)$value
}


require(REBayes)
grid <- seq(-60,60, length = 5000)
gridv <- seq(-1,1, by = 0.01)
G <- list(x = gridv, y = rep(0, length(gridv)))
G$y[which(gridv==1| gridv==-1)] = 1/2
fh <- HodgesLehmann(grid, G, alpha = 0.6)
fm <- HodgesLehmann(grid,G,alpha = 0.6, type="Mallows")
dh <- approxfun(grid, fh$d)
dm <- approxfun(grid,fm$d)

risk_theta_res <- function(theta, rule, lower = -Inf, upper = Inf) {
  integrand <- function(x) {
    fx_theta <- dnorm(x, mean = theta, sd = 1)
    loss <- (rule(x) - theta)^2
    loss * fx_theta
  }
  integrate(integrand, lower = lower, upper = upper)$value
}

# Grid of theta values
theta_grid <- seq(-1, 1, by = 0.01)

# Compute risk for each theta
risk_values <- sapply(theta_grid, risk_theta)

risk_values_resH <- sapply(theta_grid, risk_theta_res, rule = dh, lower = -30, upper = 30)
risk_values_resM <- sapply(theta_grid, risk_theta_res, rule = dm, lower = -8, upper = 8)


		
ys = seq(-5,5,by = 0.01)

pdf("2ptrisk.pdf")
plot(theta_grid, risk_values, type="l",
     ylim = c(0, 2),xlim = c(-1,1),xlab = expression(theta), ylab = expression(R(theta)))
     abline(h = 1, lty = 2)
     lines(theta_grid, risk_values_resH,col=2)
     lines(theta_grid, risk_values_resM + .01,col=4)
     legend("topleft", c("Bayes","Huber","Mallows"), col=c(1,2,4),lty = c(1,1,1))
     rug(c(1,-1),lwd = 2)
dev.off()
     
   
     
