# Plot decision rules for various estimators used in uniform simulation


Mallows <- function(grid, gridg, alpha, ...){
  require(Rmosek)
  m <- length(grid)
  p <- length(gridg)
  n <- (p - 1)/2
  dots <- list(...)
  rtol <- ifelse(length(dots$rtol), dots$rtol, 1e-06)
  verb <- ifelse(length(dots$verb), dots$verb, 0)
  G <- cbind(spMatrix(n, 4*m-3), Diagonal(n), spMatrix(n, 1), 
             sparseMatrix( i = 1:n, j = n:1, x = rep(-1, n), dims = c(n, n)))
  A = cbind(Diagonal(m), spMatrix(m, 3*m-3), -dnorm(outer(grid, gridg, "-")))
  P <- list()
  P$sense <- "min"
  P$c <- c(rep(0,3*m-2), rep(1,m-1), rep(0, p))
  P$A <- rbind(A, G, 
               c(rep(0, 4*m-3), rep(0, n), 1, rep(0, n)),
               c(rep(0, 4*m-3), rep(1, p)),
               cbind(diff(Diagonal(m)), -Diagonal(m-1), spMatrix(m-1,2*m-2+p)),  
               cbind(abs(diff(Diagonal(m))), spMatrix(m-1,m-1), -Diagonal(m-1),
                     spMatrix(m-1,m-1+p)))
  lhs <- c(rep(0, m), rep(0, n), alpha, 1, rep(0, 2*m-2))
  P$bc <- rbind(lhs,lhs)   
  P$bx <- rbind(c(rep(0,m),rep(-Inf,m-1),rep(0,2*m-2),  rep(0, p)),
                c(rep(Inf,4*m-3+p)))
  js = cbind((2*m-1)+(1:(m-1)), (3*m-2)+(1:(m-1)), m+(1:(m-1)))               
  P$F = sparseMatrix(i = 1:(3*(m-1)), j = c(t(js)), 
                     x = rep(1, 3*(m-1)), dims = c(3*(m-1), 4*m-3+p))
  P$g = c(rep(0, 3*(m-1)))
  P$cones <-  matrix(list(),nrow=3,ncol=m-1)
  rownames(P$cones) = c("type", "dim", "conepar")
  for (k in 1:(m-1))
    P$cones[,k] <- list("RQUAD", 3, NULL)
  P$dparam$intpnt_co_tol_rel_gap <- rtol
  res <- Rmosek::mosek(P, opts = list(verbose = verb))
  z <- list(x = grid, y = res$sol$itr$xx[1:m], 
            v = gridg, g = res$sol$itr$xx[-c(1:(4*m-3))])
  class(z) <- "density"
  return(z)
}

dmallows <- function(x, eps, a = 30, b = 20, ...) {
    grid = seq(-a,a,length = 500)
    gridg = c(seq(-b, 0.01, by = 0.01), 0, seq(0.01, b, by = 0.01))
    z <- Mallows(grid, gridg, 1 - eps)
    Z <- approxfun(z$x, z$y)
    Z(x)
    }

dLaplace <- function(x, scale = 1)
    .5 * exp(-abs(x)/scale)/scale
huberk <- function(eps) {
    v <- function(k, eps) 2 * dnorm(k)/k - 2 * pnorm(-k) - eps/(1-eps)
    uniroot(v, c(0.1, 3), eps = eps)$root
}
Rule <- function(x, G, type = "Gauss", eps = 0.1){
    if(type == "Huber") k <- huberk(eps)
    y <- switch(type,
		  Gauss = dnorm(x),
		  Huber = dhuber(x, k = k),
		  Mallows = dmallows(x, eps)
		  )
    phi <- approxfun(x,y)
    A <- matrix(phi(outer(x, G$x, "-")),length(x), length(G$x))
    fg <- as.vector(A %*% G$y)
    as.vector(A %*% (G$y * G$x))/fg
}
require(REBayes)
require(VGAM)
pdf("rules.pdf", height = 5, width = 5)

x <- -50:100/10
G <- list(x = 1:299/100, y = rep(1/300, 299))
plot(x, Rule(x, G), type = "l", lwd = 2, ylab = "d(x)")
lines(x, Rule(x, G, type = "Huber"), col = 2, lwd = 2)
lines(x, Rule(x, G, type = "Mallows"), col = 4, lwd = 2)
abline(c(0,1), lty = 2, lwd = 2)
legend("topleft", c("Gauss", "Huber", "Mallows"), col = c(1,2,4), lty = 1, lwd = 2)
dev.off()
