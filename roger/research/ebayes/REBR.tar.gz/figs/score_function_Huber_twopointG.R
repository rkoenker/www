# -----------------------------------------
# Plot patched g, with g0 in the background
# G0 = 0.5 delta_{-2} + 0.5 delta_2
# -----------------------------------------

# Choose k
k <- 1

# g0(x) = (log f_G0(x))' for G0 = 0.5 delta_{-2} + 0.5 delta_2
g0 <- function(x) {
  2 * tanh(2 * x) - x
}

# Center piece: k tanh(kx/2)
g_center <- function(x, k) {
  k * tanh(k * x / 2)
}

# Equation for c: g0(c) = k tanh(kc/2)
f_c <- function(x, k) {
  g0(x) - g_center(x, k)
}

# Equation for b: g0(b) = -k
f_b <- function(x, k) {
  g0(x) + k
}

# Find first positive root for c
find_c <- function(k, xmax = 10, ngrid = 5000) {
  xs <- seq(1e-6, xmax, length.out = ngrid)
  ys <- f_c(xs, k)
  idx <- which(head(ys, -1) * tail(ys, -1) <= 0)
  if (length(idx) == 0) stop("No positive root found for c.")
  i <- idx[1]
  uniroot(function(x) f_c(x, k), c(xs[i], xs[i + 1]))$root
}

# Find first positive root for b
find_b <- function(k, xmax = 20, ngrid = 5000) {
  xs <- seq(1e-6, xmax, length.out = ngrid)
  ys <- f_b(xs, k)
  idx <- which(head(ys, -1) * tail(ys, -1) <= 0)
  if (length(idx) == 0) stop("No positive root found for b.")
  i <- idx[1]
  uniroot(function(x) f_b(x, k), c(xs[i], xs[i + 1]))$root
}

c_val <- find_c(k)
b_val <- find_b(k)

cat("k =", k, "\n")
cat("c =", c_val, "\n")
cat("b =", b_val, "\n")

# Patched g(x)
g <- function(x, k, c, b) {
  out <- numeric(length(x))

  out[x <= -b] <- k
  out[x > -b & x < -c] <- g0(x[x > -b & x < -c])
  out[abs(x) <= c] <- g_center(x[abs(x) <= c], k)
  out[x > c & x < b] <- g0(x[x > c & x < b])
  out[x >= b] <- -k

  out
}

# Grid for plotting
x <- seq(-7, 7, length.out = 2000)
y_g0 <- g0(x)
y_g  <- g(x, k, c_val, b_val)

# Plot main curve first
pdf("score_function_Huber_twopointG.pdf")
plot(x, y_g, type = "l", lwd = 3, col = "firebrick",
     ylim = range(c(y_g0, y_g, -k, k)),
     xlab = "x", ylab = "value", xaxt = "n",
     main = bquote("Huber Score vs original Score,  k =" ~ .(k)))

# Add g0 in lighter dotted style
lines(x, y_g0, lwd = 2, lty = 3, col = "gray70")

# Reference lines
abline(h = c(-k, k), lty = 3, col = "gray50")
abline(v = c(-b_val, -c_val, c_val, b_val), lty = 2, col = "gray60")

axis(1,
at = c(-b_val, -c_val, c_val, b_val),
labels = c("-b", "-c", "c", "b"))
# Mark junction points
points(c(-b_val, -c_val, c_val, b_val),
       g(c(-b_val, -c_val, c_val, b_val), k, c_val, b_val),
       pch = 19, col = "black")

legend("topright",
       legend = c(expression(g(x)), expression(g[0](x))),
       col = c("firebrick", "gray70"),
       lwd = c(3, 2),
       lty = c(1, 3),
       bty = "n")
    
dev.off()