
risk_theta_res <- function(theta, rule, lower = -Inf, upper = Inf) {
  integrand <- function(x) {
    fx_theta <- dnorm(x, mean = theta, sd = 1)
    loss <- (rule(x) - theta)^2
    loss * fx_theta
  }
  integrate(integrand, lower = lower, upper = upper)$value
}

require(REBayes)
# {-2,2} equality probablity G.
set.seed(78)
a =  60
grid <- seq(-a,a,length = 2500)
gridv <- seq(-a,a,by = 0.01)
G <- list(x = gridv, y = rep(0, length(gridv)))
G$y[which(gridv==2 | gridv== -2)] = 1/2
#G$y[which(gridv==0)] = 1

f2 <- HodgesLehmann(grid, G, alpha = 0.8, type="Mallows")
dm <- approxfun(grid, f2$d)
theta_grid <- seq(-32,32,by = 0.02)
risk_values_resM <- sapply(theta_grid, risk_theta_res, rule = dm, lower = -60, upper = 60)
pdf("HLmass.pdf")
plot(theta_grid, risk_values_resM,type="l", lwd = 2,
     xlab = expression(theta), ylab = expression(nabla * Psi ( theta )), xlim = c(-16,16))
t <- gridv[sqrt(f2$H) > 0.001]
h <- sqrt(f2$H[sqrt(f2$H) > 0.001])
B <- risk_theta_res(gridv[which.max(f2$H)], rule = dm, lower = -60, upper = 60)
abline(h = B, lty = 2) 
segments(t,rep(B,length(t)),t, B-h, col = 3, lwd = 2)
dev.off()
