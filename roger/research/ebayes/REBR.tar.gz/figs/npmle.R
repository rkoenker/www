collapse <- function(f, eps = 0.001){
    # kludgy aggregation of neighboring mass points
    # beware:  presumes at most two neighbors
    z <- rle(f$y > eps)$lengths
    s <- cumsum(z)
    t <- s[z == 2] - 1
    for(i in 1:length(t)){
	f$y[t[i]] <- sum(f$y[t[i]:(t[i]+1)]) 
	f$y[t[i]+1] <- 0
    }
    f
}

require(REBayes)
pdf("npmle.pdf", height = 5, width = 10)
set.seed(9)
par(mfrow = c(1,2))
a = 10
n = 500
grid = seq(-a,a,length = 500)
mu <- runif(n, 0,3)
y <- mu + rnorm(n)
v <- seq(-5,8, by = 0.02)
G <- GLmix(y, v, rtol = 1e-10)
G <- collapse(G)
f0 <- HodgesLehmann(grid, G, alpha = 0.9, rtol = 1e-10)
f1 <- HodgesLehmann(grid, G, alpha = 0.9, type = "Mallows", rtol = 1e-10)
G1 <- list(x = G$x, y = 0.9*G$y + 0.1*f1$H)
G1 <- collapse(G1)
plot(G, lwd = 3, xlab = expression(theta), ylab = expression(G (theta)), main = "",sub = "")
lines(G1, col = 2, lwd = 2) 
legend("topleft", c("NPMLE", "Mallows NPMLE"), col = 1:2, cex = .8, lwd = 2)

d1 <- f1$x[-1]+diff(log(f1$y))/diff(f1$x)
d0 <- f0$x[-1]+diff(log(f0$y))/diff(f0$x)

d1f <- approxfun(f1$x[-1], d1)
d0f <- approxfun(f0$x[-1],d0)

yy <- seq(-2.5, 5.5, by = 0.01)
A <- dnorm(outer(yy, G$x, "-"))
d2  <- as.vector((A %*% (G$y * G$x))/(A %*% G$y))
d2f <- approxfun(yy, d2)

plot(yy, d1f(yy), type="l", xlab = "x", ylab = "d(x)", lwd = 2)
lines(yy, d0f(yy), col = 2, lwd = 2)
lines(yy, d2f(yy), col = 4, lwd = 2)
abline(c(0,1), lty = 3, lwd = 2)
legend("topleft", c("Huber", "Mallows", "NPMLE"), cex = 0.8, lty = 1, col = c(2:1,4), lwd = 2)
dev.off()
