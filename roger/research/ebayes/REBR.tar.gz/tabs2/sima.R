# Table for both simulations
load("sim2.Rda")
B2 <- round(apply(A,1:2, mean), 3) 
Hlab <- paste("HLmix(", c(0.2,0.1,0.05,0.025),")", sep = "")
Mlab <- paste("MLmix(", c(0.2,0.1,0.05,0.025),")", sep = "")
dimnames(B2) <- list(c("GLmix", "LLmix","Oracle", Hlab, Mlab),
		    c("Tukey", "Laplace","Gauss"))
# Table for sim1
load("sim1.Rda")
B1 <- round(apply(A,1:2, mean), 3) 
Hlab <- paste("HLmix(", c(0.2,0.1,0.05,0.025),")", sep = "")
Mlab <- paste("MLmix(", c(0.2,0.1,0.05,0.025),")", sep = "")
dimnames(B1) <- list(c("GLmix", "LLmix","Oracle", Hlab, Mlab),
		    c("Tukey", "Laplace","Gauss"))
B <- cbind(B2, B1)
B <- B[c(3,1,2,4:11),]
require(Hmisc)
cap = "Mean Squared Error of Several Compound Decision Rules"
latex(B, file = "sima.tex", label = "tab.sim", rowlabel = "",
      cgroup = c("$G \\sim 0.9 \\delta_0 + 0.1 \\delta_3$", "$G  \\sim U[0,3]$"),
      caption = cap, cap.loc = "bottom")

