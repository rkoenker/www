# Simulation of Huber and Mallows KW Performance  G ~ U[0,3]
###
###  Minimal Fisher (location) information via conic optimization
###  Mallows's Problem 78.4
###
###           ( f_{i+1}-f_i )^2       u_i^2
###   min sum ----------------- = sum -----  ~> I(F)
###           ( f_{i+1}+f_i )/2       v_i/2
###
###              <=>    min sum w_i  when u_i^2 <= 2 v_i w_i
###
###   subject to f = phi * g, g(-x) = g(x), for all x !=0, g(0) = alpha \in [0,1]
###
###   vars:     f    u    v    w   g
###   lengths:  m   m-1  m-1  m-1  p
###
###   When the grid is not equispaced, one would have to include grid spacings.


Mallows <- function(grid, gridg, alpha, ...){
  require(Rmosek)
  m <- length(grid)
  p <- length(gridg)
  n <- (p - 1)/2
  dots <- list(...)
  rtol <- ifelse(length(dots$rtol), dots$rtol, 1e-06)
  verb <- ifelse(length(dots$verb), dots$verb, 0)
  G <- cbind(spMatrix(n, 4*m-3), Diagonal(n), spMatrix(n, 1), 
             sparseMatrix( i = 1:n, j = n:1, x = rep(-1, n), dims = c(n, n)))
  A = cbind(Diagonal(m), spMatrix(m, 3*m-3), -dnorm(outer(grid, gridg, "-")))
  P <- list()
  P$sense <- "min"
  P$c <- c(rep(0,3*m-2), rep(1,m-1), rep(0, p))
  P$A <- rbind(A, G, 
               c(rep(0, 4*m-3), rep(0, n), 1, rep(0, n)),
               c(rep(0, 4*m-3), rep(1, p)),
               cbind(diff(Diagonal(m)), -Diagonal(m-1), spMatrix(m-1,2*m-2+p)),  
               cbind(abs(diff(Diagonal(m))), spMatrix(m-1,m-1), -Diagonal(m-1),
                     spMatrix(m-1,m-1+p)))
  lhs <- c(rep(0, m), rep(0, n), alpha, 1, rep(0, 2*m-2))
  P$bc <- rbind(lhs,lhs)   
  P$bx <- rbind(c(rep(0,m),rep(-Inf,m-1),rep(0,2*m-2),  rep(0, p)),
                c(rep(Inf,4*m-3+p)))
  js = cbind((2*m-1)+(1:(m-1)), (3*m-2)+(1:(m-1)), m+(1:(m-1)))               
  P$F = sparseMatrix(i = 1:(3*(m-1)), j = c(t(js)), 
                     x = rep(1, 3*(m-1)), dims = c(3*(m-1), 4*m-3+p))
  P$g = c(rep(0, 3*(m-1)))
  P$cones <-  matrix(list(),nrow=3,ncol=m-1)
  rownames(P$cones) = c("type", "dim", "conepar")
  for (k in 1:(m-1))
    P$cones[,k] <- list("RQUAD", 3, NULL)
  P$dparam$intpnt_co_tol_rel_gap <- rtol
  res <- Rmosek::mosek(P, opts = list(verbose = verb))
  z <- list(x = grid, y = res$sol$itr$xx[1:m], 
            v = gridg, g = res$sol$itr$xx[-c(1:(4*m-3))])
  class(z) <- "density"
  return(z)
}

collapse <- function(f, eps = 0.01){
  # kludgy aggregation of neighboring mass points
  # beware:  presumes at most two neighbors
  z <- rle(f$g > eps)$lengths
  s <- cumsum(z)
  t <- s[z == 2] - 1
  for(i in 1:length(t)){
    f$g[t[i]] <- sum(f$g[t[i]:(t[i]+1)]) 
    f$g[t[i]+1] <- 0
  }
  f
}
LLmix <- function(x, v = 300, weights = NULL, ...){
    dn <- length(x)
    eps <- 1e-04
    if (length(v) == 1) 
	v <- seq(min(x) - eps, max(x) + eps, length = v)
    m <- length(v)
    weights <- weights/sum(weights)
    w <- weights
    if (!length(w)) 
	w <- rep(1, n)/n
    d <- rep(1, length(v))
    A <- dLaplace(outer(x, v, "-"))
    A <- matrix(A, n, m, byrow=FALSE)
    f <- KWDual(A, d, w, ...)
    y <- f$f
    g <- f$g
    dy <- as.vector((A %*% (y * d * v))/g)
    z <- list(x = v, y = y, g = g,  
		dx = x, dy = dy, A = A, status = f$status)
    class(z) <- c("GLmix", "density")
    return(z)
    }

MLmix <- function(x, v = 300, alpha, weights = NULL, a = 30, b = 20, ...) {
    grid = seq(-a,a,length = 500)
    gridg = c(seq(-b, 0.01, by = 0.01), 0, seq(0.01, b, by = 0.01))
    z <- Mallows(grid, gridg, alpha)
    dmallows <- approxfun(z$x, z$y)
    dn <- length(x)
    eps <- 1e-04
    if (length(v) == 1) 
	v <- seq(min(x) - eps, max(x) + eps, length = v)
    m <- length(v)
    weights <- weights/sum(weights)
    w <- weights
    if (!length(w)) 
	w <- rep(1, n)/n
    d <- rep(1, length(v))
    A <- dmallows(outer(x, v, "-"))
    A <- matrix(A, n, m, byrow=FALSE)
    f <- KWDual(A, d, w, ...)
    y <- f$f
    g <- f$g
    dy <- as.vector((A %*% (y * d * v))/g)
    z <- list(x = v, y = y, g = g,  
		dx = x, dy = dy, A = A, status = f$status)
    class(z) <- c("GLmix", "density")
    return(z)
    }


DGP <- function(dgp, n = 500){
    z <- switch(dgp,
	function(n = n, alpha = 0.1, sigma = 3, beta = 0.2, theta = 3){
	    mu <- runif(n, min = 0, max = theta)
	    sd <- sample(c(1, sigma), n, replace = TRUE, prob = c(1-alpha,alpha))
	    u <- rnorm(n, 0, sd = sd)
	    y <- mu + u
	    list(y = y, mu = mu, alpha = alpha, sigma = sigma, beta = beta)
	    },
	function(n = n, scale = sqrt(1/2), beta = 0.2, theta = 3){
	    mu <- runif(n, min = 0, max = theta)
	    u <- rlaplace(n, scale = scale)
	    y <- mu + u
	    list(y = y, mu = mu, scale = scale, beta = beta)
	    },
	function(n = n, sigma = 1, beta = 0.2, theta = 3){
	    mu <- runif(n, min = 0, max = theta)
	    u <- rnorm(n, sd = sigma)
	    y <- mu + u
	    list(y = y, mu = mu, sigma = sigma, beta = beta)
	    }
	)
    z
}

Oracle <- function(dgp, D){
    z <- switch(dgp,
	# Oracle knows true base distribution
	function(D){ # Oracle: knows G_n, edf of the mu's
	    y <- D$y
	    mu <- D$mu
	    G <- list(x = seq(0,3,length = 300), y = dunif(seq(0,3,length=300), 0,3))
	    dgmix <- function(u, alpha, sigma)
		(1-alpha)*dnorm(u) + alpha * dnorm(u, sd = sigma)
	    A <- dgmix(outer(y, G$x, "-"), alpha  = D$alpha , sigma = D$sigma)
	    as.vector((A %*% (G$y * G$x))/(A %*% G$y))
	    },
	function(D){ # Oracle: knows G_n, edf of the mu's
	    y <- D$y
	    mu <- D$mu
	    G <- list(x = seq(0,3,length = 300), y = dunif(seq(0,3,length=300), 0,3))  
	    A <- dLaplace(outer(y, G$x, "-"), scale = D$scale)
	    as.vector((A %*% (G$y * G$x))/(A %*% G$y))
	    },
	function(D){ # Oracle: knows G_n, edf of the mu's
	    y <- D$y
	    mu <- D$mu
	    G <- list(x = seq(0,3,length = 300), y = dunif(seq(0,3,length=300), 0,3))
	    A <- dnorm(outer(y, G$x, "-"), sd = D$sigma)
	    as.vector((A %*% (G$y * G$x))/(A %*% G$y))
	    }
    )
}
dLaplace <- function(x, scale = 1)
    .5 * exp(-abs(x)/scale)/scale
MSE <- function(muhat, mu)
    mean((muhat - mu)^2)


# DGP1: Tukey Likelihood + Unif[0,3] G0
# DGP2: Laplace likelihood (with variance 1) + Unif[0,3] G0
# DGP3: Normal likelihood + Unif[0,3] G0

require(REBayes)
require(VGAM)
set.seed(123)
R = 500
n = 500

huberks <- c(0.862, 1.135, 1.398, 1.684) 
# approximately eps = (0.2, 0.1, 0.05, 0.025)
heps <- rep(NA, length(huberks))
for(i in 1:length(huberks))
    heps[i] <- hubereps(huberks[i])

DGPs <- c("Tukey", "Laplace", "Gauss")
A <- array(0, c(2*length(heps)+3, length(DGPs), R))
for(i in 1:R){
    for (j in 1:length(DGPs)){
	D <- DGP(j)(n)
	    A[1,j,i] <- MSE(GLmix(D$y)$dy, D$mu)
	    A[2,j,i] <- MSE(LLmix(D$y)$dy, D$mu)
	    A[3,j,i] <- MSE(Oracle(j)(D = D), D$mu)
	    for(ii in 1:length(heps)){
		A[3+ii,j,i] <- MSE(HLmix(D$y, k = huberks[ii], heps = heps[ii])$dy, D$mu)
		A[length(heps)+3+ii,j,i] <- MSE(MLmix(D$y, alpha = 1-heps[ii])$dy, D$mu)
	    }
	}
    }
