# Now compute ASE and EBregret
load("sim2.Rda")
Rbar <- apply(R, 2, mean)
EBregret <- Rbar - Rbar[1]

# Now compute ASE and EBregret
require(Hmisc)
Rbar <- apply(R, 2, mean)
EBregret <- Rbar - Rbar[1]
V <- round(EBregret[c(4,5,2,3,6)],5)
names(V) <- c(rep(c("df = 5","df = 20"),2),"")
Ttab.cap <- "Empirical Bayes Regret for 'two towers' example"
latex(t(V), rowlabel = "", file = "tuning.tex", where = "!htbp",label = "tab:Ttab",
      cgroup = c("$c_0 = 1.0$", "$c_0 = 0.1$", "NPMLE"),
      n.cgroup = c(2,2,1), caption = Ttab.cap, caption.loc = "bottom")
