require(Hmisc)
load("sim11.Rda")
b1 <- apply(A, 1, mean)
load("sim10.Rda")
b0 <- apply(A, 1, mean)
B <- rbind(b0,b1)
dimnames(B) <- list(c("Smooth", "Discrete"), c("Efron", "Kernel", "NPMLE", "NPMLEs") )
decon.cap <- "Mean Wasserstein ($L_1$) Error"
latex(format(round(B,3)), rowlabel = "", file = "decon.tex", where = "!htbp",label = "tab:decon",
      caption = decon.cap, caption.loc = "bottom")
