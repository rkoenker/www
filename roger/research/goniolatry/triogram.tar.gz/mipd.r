subroutine mipd(x,y,n,d)
implicit double precision(a-h,o-z)
dimension x(n), y(n)

d   = 0.d0
div = dble(n*(n-1)/2)

do i = 2,n {
	do j = 1,i-1 {
		d = d + sqrt((x(i)-x(j))**2 + (y(i)-y(j))**2)
	}
}

d = d/div

return
end
