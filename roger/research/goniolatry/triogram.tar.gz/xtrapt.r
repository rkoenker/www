subroutine xtrapt(xa,ya,na,nadj,madj,x,y,ntot,eps,iadd,badd,nedge,nerror)

implicit double precision(a-h,o-z)
dimension nadj(-3:ntot,0:madj), x(-3:ntot), y(-3:ntot)
dimension xa(na),ya(na),badd(3,na)
integer tau(3),iadd(3,na),nedge(na)

j=2
do i= 1,na{
	xadd = xa(i)
	yadd = ya(i)
	call triget(xadd,yadd,j,tau,nedge(i),nadj,madj,x,y,ntot,eps,nerror)
	if(nerror>0) return
	iadd(1,i) = tau(1)
	iadd(2,i) = tau(2)
	iadd(3,i) = tau(3)
# Compute barycentric coordinates for the extra points.
	x1=x(iadd(1,i))
	y1=y(iadd(1,i))
	x2=x(iadd(2,i))
	y2=y(iadd(2,i))
	x3=x(iadd(3,i))
	y3=y(iadd(3,i))
	call triar(xadd,yadd,x2,y2,x3,y3,badd(1,i))
	call triar(x1,y1,xadd,yadd,x3,y3,badd(2,i))
	call triar(x1,y1,x2,y2,xadd,yadd,badd(3,i))
	call triar(x1,y1,x2,y2,x3,y3,total)
	badd(1,i)=badd(1,i)/total
	badd(2,i)=badd(2,i)/total
	badd(3,i)=badd(3,i)/total
	j=iadd(1,i)
	}
return
end
