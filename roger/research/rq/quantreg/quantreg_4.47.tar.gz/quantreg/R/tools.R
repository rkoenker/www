"FAQ" <- function(pkg = "quantreg")
     file.show(file.path(system.file(package = pkg),"FAQ"))
"ChangeLog" <- function(pkg = "quantreg")
     file.show(file.path(system.file(package = pkg),"ChangeLog"))
"vignette" <- function(topic, package = NULL, lib.loc = NULL, all = TRUE){
     if(package == "quantreg")
        faux.vignette(topic,  pkg = package)
     else
        utils::vignette(topic, package = package, lib.loc = lib.loc, all = all)
}
"faux.vignette" <- function(topic, pkg = "quantreg"){
    #kludge to allow search or viewing of faux vignettes
    if(missing(topic)){
        dir <- system.file("doc", package = pkg)
        return(gsub(".pdf","", list.files(dir,".pdf")))
        }
    else{
       file <- system.file( "doc", paste(topic,".pdf",sep = ""), package = pkg)
       z <- list( pdf = file, topic = vignette)
       class(z) <-   "vignette"
       return(z)
    }
}

