#Demo for a Plot of Engel curve in sample space

data(engel)
attach(engel)
plot(x,y,cex=.25,type="n",xlab="Household Income", ylab="Food Expenditure")
points(x,y,cex=.5,col="blue")
abline(rq(y~x,tau=.5),col="blue")
abline(lm(y~x),lty=2,col="red") #the dreaded ols line
taus <- c(.05,.1,.25,.75,.90,.95)
for( i in 1:length(taus)){
        abline(rq(y~x,tau=taus[i]),col="gray")
        }

