#First stage of Monte-Carlo to check size of the Sup LR and Sup LM QR Tests
dyn.load("rq.o")
#a1 refers to linear shift model
#a2 refers to quadratic heteroscedasticity model
#a3 refers to bimodal transition model
mc.a1.G.500_monte.carlo(2,model= expression(.5*x[,1] +rnorm(n)))
#mc.a1.t1.500_monte.carlo(3,model= expression(x[,1] +rt(n,1)))
#mc.a1.x4.500_monte.carlo(3,model= expression(x[,1] +rchisq(n,4)))
#mc.a0.G.500_monte.carlo(4,model= expression(rnorm(n)))
#mc.a0.t1.500_monte.carlo(5,model= expression(rt(n,1)))
#mc.a0.x4.500_monte.carlo(5,model= expression(rchisq(n,4)))

