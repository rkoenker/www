#S source for Table 5.1 of R1 paper
calpha <- matrix(c( 8.19, 11.2, 15.62, 9.84, 12.93, 17.56, 13.01, 16.44, 21.54
), 3)
alphas_format(round(c(.10,.05,.01),2))
#table.5.1 <- format(round(calpha,2))
table.5.1 <- calpha
dimnames(table.5.1)_list(c(1,2,4),paste("$\\alpha =$",alphas,sep=""))
latex.table(table.5.1, rowlabel="$q$",label="", dec=2,
caption="Critical Values for $\\sup \\Lambda_n$ and $\\sup T_n$  Tests:
The entries constitute a small extract from a much larger
table of Andrews (1993).  Each entry is $c_{\\alpha}$
such that $\\mbox{Prob}( \\sup_{\\{\\tau \\in 
[ .05 , .95 ] \\}} Q_q^2 < c_{\\alpha} ) = \\alpha$.  
The ``degrees of freedom'' parameter $q$ is the number of linear
restrictions imposed by the null hypothesis.  These critical values
are employed below in the Monte-Carlo evaluation of the size
and power performance of the tests.")
