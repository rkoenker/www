#test source file for bimodal example F tests
dyn.load("Gmix.o")
n_100
R_100
x_runif(n)
y_matrix(runif(n*R),n)
#this particular parametrization was cooked to give 0 mean and approximately
#identical scale -- using the L-stat for scale with PHI^{-1} score function.
means_c(-1.08,1.08)
sigmas_c(1/8,1/8)
w0_matrix(qnorm(y),n)
w1_matrix(qgmix(y,eps=.5,s=sigmas,m=means),n)
y_w0*(1-x) + w1*x
plot(x,y[,1],xlab="",ylab="")
browser()
Fs.bim_F.test(x,y)
