

#Third stage of Monte-Carlo to check power of the Sup LR and Sup LM QR Tests
dyn.load("rq.o")
dyn.load("Gmix.o")
mc.a3.bim.500_monte.carlo(6,model= expression(rbimodal(x[,1])))
#mc.a3.h.500_monte.carlo(6,model= expression(rhetero(x[,1])))


