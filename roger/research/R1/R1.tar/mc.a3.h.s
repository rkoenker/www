
#Third stage of Monte-Carlo to check power of the Sup LR and Sup LM QR Tests
dyn.load("rq.o")
mc.a3.h.500_monte.carlo(6,model= expression(rhetero(x[,1])))

