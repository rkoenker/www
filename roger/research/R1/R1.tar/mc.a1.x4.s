#First stage of Monte-Carlo to check size of the Sup LR and Sup LM QR Tests
dyn.load("rq.o")
#a1 refers to linear shift model
#a2 refers to quadratic heteroscedasticity model
#a3 refers to bimodal transition model
mc.a1.x4.500_monte.carlo(3,model= expression(.5*x[,1] +rchisq(n,4)))

