#test source file for linear model example F tests
n_100
R_100
x_runif(n)
y_x + matrix(rt(n*R,1),n)/2
#plot(x,y[,1],xlab="",ylab="")
Fs_F.test(x,y)
