## ----preliminaries, echo=FALSE, warning = FALSE, message = FALSE, results='hide'----
knitr::render_sweave()
options(prompt = "R> ", continue = "+  ", digits = 2, show.signif.stars = FALSE)
cleanup <- FALSE

